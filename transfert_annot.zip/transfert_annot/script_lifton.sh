#! /bin/bash

# arguments 
sp=$1

# script
mkdir ${sp}
cd ${sp}
cp ~/Primates/GFF_files/Homo_sapiens/Homo_sapiens_genome_annotation.gff .
cp ~/Primates/Data/${sp}_genome.fasta .
cp ~/Primates/Data/Homo_sapiens_genome.fasta .
export PATH=$PATH:~/bin/miniprot/ 
lifton -g Homo_sapiens_genome_annotation.gff -o ${sp}_genome_annotation.gff -copies ${sp}_genome.fasta Homo_sapiens_genome.fasta -a 0.8 -s 0.8 2>${sp}_annotation_error.txt > ${sp}_annotation_out.txt
rm Homo_sapiens_genome_annotation.gff
rm ${sp}_genome.fasta
rm Homo_sapiens_genome.fasta
rm *fai
rm *mmi
rm *_db
cd ..
