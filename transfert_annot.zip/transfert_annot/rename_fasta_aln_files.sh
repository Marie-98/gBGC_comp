for file_name in $(cat list_files_aln.txt) ; do
	#echo $file_name
	echo $file_name > name_${file_name}.txt
	gene=$(cut -f2 -d"_" name_${file_name}.txt)
	#echo $gene
	exon_pos=$(cut -f4 -d"_" name_${file_name}.txt)
	#echo $exon_pos
	exon_name=$(echo -e "${gene}Exon${exon_pos}")
	#echo $exon_name
	renamed_file_name_NT=$(echo -e "${gene}_${exon_name}_${exon_pos}_final_align_NT_wt_ref_filtered.fasta")
	#echo $renamed_file_name_NT
	ancient_name_AA_file=$(echo -e "AA_${file_name}")
	#echo $ancient_name_AA_file
	new_name_AA_file=$(echo -e "${gene}_${exon_name}_${exon_pos}_final_mask_align_AA.aln")
	#echo $new_name_AA_file
	echo -e "${file_name}\t${renamed_file_name_NT}\t${ancient_name_AA_file}\t${new_name_AA_file}" >> rename_fasta_aln_files.txt ;
done > out_rename.txt

for file_name in $(cat list_files_aln.txt) ; do
	new_name=$(grep -w "$file_name" rename_fasta_aln_files.txt | cut -f2)
	mv $file_name $new_name ;
done
	
for file_AA_name in $(cat list_files_AA_aln.txt) ; do
	new_AA_name=$(grep -w "$file_AA_name" rename_fasta_aln_files.txt | cut -f4)
	mv $file_AA_name $new_AA_name ;
done
