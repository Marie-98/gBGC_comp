#! /bin/bash

# input files

GENE=$1

# script

for sp in $(cat ~/Primates/Gene_alignments/genes_info/${GENE}_sp_list.txt) ; do
echo -e "${sp}"

	# table of CDS positions

	gene_id=$(grep "=${GENE};" ~/Primates/GFF_files/${sp}/${sp}_genome_annotation.gff | cut -f9 | cut -f1 -d";" | cut -f2 -d":" | sort | head -1)
	transcript_id=$(grep -w "${gene_id}" ~/Primates/GFF_files/${sp}/${sp}_genome_annotation.gff | grep $'mRNA\t' | cut -f9 | cut -f1 -d';' | cut -f2 -d':')
	grep -w "Parent=transcript:${transcript_id}" ~/Primates/GFF_files/${sp}/${sp}_genome_annotation.gff | grep $'CDS\t' | cut -f4,5 > ${GENE}_cds_positions_${sp}.csv

	# gene direction

	gene_direction=$(grep -w "${gene_id}" ~/Primates/GFF_files/${sp}/${sp}_genome_annotation.gff | grep $'mRNA\t' | cut -f7)
	echo -e "${gene_direction}"

	# name of the sequence into which the gene is located	

	seq_name=$(grep -w "${gene_id}" ~/Primates/GFF_files/${sp}/${sp}_genome_annotation.gff | grep $'mRNA\t' | cut -f1)
	#complete_seq_name=$(grep ">${seq_name}" ~/Primates/Data/${sp}_genome.fasta | sed 's/>//g')
	
	# gene sequence	
	python3 ~/scripts/script_extract_seq.py ${GENE}_cds_positions_${sp}.csv $gene_direction ~/Primates/Data/${sp}_genome.fasta "${seq_name}" ${sp}_${GENE}_seq.txt

	# add the gene sequence of the specie in a fasta file

	echo -e ">${sp}" >> ${GENE}_seq.fasta
	cat ${sp}_${GENE}_seq.txt >> ${GENE}_seq.fasta
	
done

