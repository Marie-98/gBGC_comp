#! /bin/bash

# input file : transfer gff
GFF_TRANSFERT=$1

# count gene number in transfer gff
nb_genes_transfert=$(grep -c $'\tgene\t' ${GFF_TRANSFERT})
echo -e "Number of genes in transfer gff: ${nb_genes_transfert}"
# count CDS number in transfer gff
nb_CDS_transfert=$(grep -c $'\tCDS\t' ${GFF_TRANSFERT})
echo -e "Number of CDS in transfer gff: ${nb_CDS_transfert}"

# liste genes dans le transfert
grep $'\tgene\t' ${GFF_TRANSFERT} | cut -f9 | cut -f2 -d';' | grep "Name" | cut -f2 -d'=' | sort -u > genes_list_transfer.txt

# number of genes of ref gff found in the target genome
comm -12 ~/Primates/GFF_files/Hsap_OMMgenes_reprmRNA/genes_list_ref.txt genes_list_transfer.txt > genes_list_comm_ref_transfer.txt
count_genes_comm=$(wc -l < genes_list_comm_ref_transfer.txt)
echo -e "Number of genes of reference gff found in the target genome: ${count_genes_comm}"

# count number of CDS per gene 
echo -e "gene\ttranscript_transfer\tCDS_nb_transfer" > CDS_nb_per_gene_transfer.csv

for gene in $(cat genes_list_comm_ref_transfer.txt) ; do
	gene_id_transfert=$(grep "=${gene};" ${GFF_TRANSFERT} | cut -f9 | cut -f1 -d";" | cut -f2 -d":")
	nb_transcript_transfert=$(grep -w "${gene_id_transfert}" ${GFF_TRANSFERT} | grep -c $'mRNA\t')
	echo -e "${gene}\t${nb_transcript_transfert}" >> transcripts_nb_transfer.txt
	if [ "${nb_transcript_transfert}" == 1 ]; then
		id_transcript_transfert=$(grep -w "${gene_id_transfert}" ${GFF_TRANSFERT} | grep $'mRNA\t' | cut -f9 | cut -f1 -d';' | cut -f2 -d':')
		nb_cds_transfert=$(grep ${id_transcript_transfert} ${GFF_TRANSFERT} | grep -c $'CDS\t')
		echo -e "${gene}\t${id_transcript_transfert}\t${nb_cds_transfert}" >> CDS_nb_per_gene_transfer.csv ;
	fi;
done

# merge CDS number of ref and transfer
join -j 1 <(sort CDS_nb_per_gene_transfer.csv) <(sort ~/Primates/GFF_files/Hsap_OMMgenes_reprmRNA/CDS_nb_per_gene_ref.csv) > CDS_nb_per_gene_comm_ref_transfer.csv

# number of complete genes found in the target genome (=genes with the same number of CDS in reference and target genomes)
nb_genes_complets=$(LC_ALL=en_US awk '{if ($3==$5) {print $0}}' CDS_nb_per_gene_comm_ref_transfer.csv | wc -l)
echo -e "Number of genes with same number of CDS in reference and transfer gff: ${nb_genes_complets}"





	
