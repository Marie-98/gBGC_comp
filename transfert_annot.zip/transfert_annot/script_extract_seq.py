## install packages ###
import sys
import pandas as pd
from Bio import SeqIO
import numpy as np

# message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 6:
    sys.exit("ERROR : need 5 arguments : [1]table of cds positions [2]gene direction [3]sequence fasta file [4]sequence name [5]name of out fasta file")
# recuperer les arguments
tab_cds_pos_name = sys.argv[1]
gene_direction = sys.argv[2]
fasta_file = sys.argv[3]
seq_name = sys.argv[4]
out_seq_name = sys.argv[5]

print(seq_name)

## script ###

tab_cds_pos = pd.read_csv(tab_cds_pos_name, sep="\t", header=None)
tab_cds_pos.columns = ['start', 'end']


if gene_direction == "-":
    tab_cds_pos = pd.DataFrame(np.flipud(tab_cds_pos))

with open(out_seq_name, 'w') as out:
    for seq_read in SeqIO.parse(fasta_file, "fasta"):
        print(seq_read.id)
        if seq_read.id == seq_name:
            seq = seq_read.seq
    for cds in tab_cds_pos.itertuples():
        pos_start = cds[1] - 1
        print(pos_start)
        pos_end = cds[2]
        print(pos_end)
        subseq = seq[pos_start:pos_end]
        if gene_direction == "-":
            subseq = subseq.reverse_complement()
        out.write(f'{subseq}')
    out.write(f'\n')

