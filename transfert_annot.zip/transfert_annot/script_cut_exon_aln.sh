#! /bin/bash

## input files

GENE=$1
TAB_POS=$2

## script

echo $GENE
echo $TAB_POS

NB_EXONS=$(sed 1d $TAB_POS | wc -l)
echo $NB_EXONS
for i in $(seq 1 ${NB_EXONS}) ; do
  echo $i
  START=$(sed 1d $TAB_POS | sed -n "${i} p"| cut -f1 -d',')
  echo $START
  END=$(sed 1d $TAB_POS | sed -n "${i} p"| cut -f2 -d',')
  echo $END
  seqkit subseq -r ${START}:${END} ../align_genes_seq/${GENE}_seq_align_NT.fasta > ${GENE}_Exon_${i}_align_NT.fasta ;
done

