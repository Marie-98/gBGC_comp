#!/usr/bin/env Rscript

# arguments
args = commandArgs(trailingOnly=TRUE)
if (length(args)<1) {
  stop("1 arguments must be supplied : [1]input table [2] output pdf-file name", call.=FALSE)
}
table_name=args[1]
pdf_name=args[2]


# load table

tab <- read.csv(table_name, header=F, sep=" ")
tab <- read.csv("CDS_nb_per_gene_comm_ref_transfer.csv", header=F, sep=" ")
tab <- tab[-nrow(tab), ]
colnames(tab) <- c("gene", "transcrit_trans", "nb_CDS_trans", "transcrit_ref", "nb_CDS_ref")
tab$compl_gene <- (tab$nb_CDS_trans/tab$nb_CDS_ref)*100
moy_compl_gene <- mean(tab$compl_gene)

#make plots

library(ggplot2)

plot_nb_CDS <- ggplot(tab, aes(nb_CDS_ref, nb_CDS_trans)) +
 geom_point(size=0.5) +
 geom_abline(slope=1, intercept = 0, size=0.2, color="red") +
 theme_bw() +
 ggtitle("For commons genes between the reference and transfer gff,
 number of CDS in the transfer gff in function of the number of 
 CDS in the reference gff; 1 point = 1 gene") +
 theme(plot.title = element_text(size = 10))
  
plot_compl_gene <- ggplot(tab, aes(compl_gene)) +
 geom_histogram(fill="grey", color="black", size=0.2) +
 theme_bw() +
 geom_vline(xintercept=moy_compl_gene, size=0.6) +
 ggtitle("How much genes are completely mapped in the target genome") +
 theme(plot.title = element_text(size = 10))
 
 destination = pdf_name
 pdf(file=destination)
 print(plot_nb_CDS)
 print(plot_compl_gene)
 dev.off()
