## Annotation Transfer from Homo sapiens
# gff file from reference genome to use : Homo_sapiens.GRCh38.112.chr.OMM.reprOrLongestProt_withoutStops.gff

cat Hominoidae_sp_list.txt | parallel -j50 ~/scripts/script_lifton.sh {}
cat Cerco_sp_list.txt | parallel -j50 ~/scripts/script_lifton.sh {}

## move the gff files to the GFF folder

cd ~/Primates/GFF_files/
for sp in $(cat ~/Primates/Annotation_transfert/Hominoidae_sp_list.txt); do
mkdir ${sp};
mv ~/Primates/Annotation_transfert/${sp}/${sp}_genome_annotation.gff ./${sp}/;
done

for sp in $(cat ~/Primates/Annotation_transfert/Cerco_sp_list.txt); do
mkdir ${sp};
mv ~/Primates/Annotation_transfert/${sp}/${sp}_genome_annotation.gff ./${sp}/;
done

## check quality of transfer

# stats on the reference genome

cd ~/Primates/GFF_files/Homo_sapiens/
~/scripts/script_stats_gff_ref.sh ~/Primates/GFF_files/Homo_sapiens/Homo_sapiens_genome_annotation.gff > stats_gff_ref_hsap.txt

cd ~/Primates/GFF_files/Macaca_mulatta/
~/scripts/script_stats_gff_ref.sh ~/Primates/GFF_files/Macaca_mulatta/Macaca_mulatta_genome_annotation.gff > stats_gff_ref_mmul.txt

# stats on the target genomes

cd ~/Primates/GFF_files/

for sp in $(cat ~/Primates/Annotation_transfert/Hominoidae_sp_list.txt); do
cd ${sp};
~/scripts/script_eval_transfert_annot_primates.sh ${sp}_genome_annotation.gff > stats_gff_transfer_${sp}.txt
~/scripts/count_dupl_genes.sh ${sp}_genome_annotation.gff 
cd ..;
done

for sp in $(cat ~/Primates/Annotation_transfert/Cerco_sp_list.txt); do
cd ${sp};
~/scripts/script_eval_transfert_annot_primates.sh ${sp}_genome_annotation.gff > stats_gff_transfer_${sp}.txt
~/scripts/count_dupl_genes.sh ${sp}_genome_annotation.gff 
cd ..;
done

# plots
cd ~/Primates/GFF_files/

for sp in $(cat ~/Primates/Annotation_transfert/Hominoidae_sp_list.txt); do
cd ${sp};
~/scripts/script_plot_stat_annot_transfer.R CDS_nb_per_gene_comm_ref_transfer.csv plot_annot_${sp};
cd ..;
done

for sp in $(cat ~/Primates/Annotation_transfert/Cerco_sp_list.txt); do
cd ${sp};
~/scripts/script_plot_stat_annot_transfer.R CDS_nb_per_gene_comm_ref_transfer.csv plot_annot_${sp};
cd ..;
done







