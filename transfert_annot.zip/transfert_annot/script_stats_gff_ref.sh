#! /bin/bash

# input file : ref gff
GFF_REF=$1

# count gene number
nb_genes_ref=$(grep -c $'\tgene\t' ${GFF_REF})
echo -e "Number of genes in reference gff: ${nb_genes_ref}"

# count CDS number
nb_CDS_ref=$(grep -c $'\tCDS\t' ${GFF_REF})
echo -e "Number of CDS in reference gff: ${nb_CDS_ref}"

# genes list
grep $'\tgene\t' ${GFF_REF} | cut -f9 | cut -f2 -d';' | grep "Name" | cut -f2 -d'=' | sort -u > genes_list_ref.txt

# count number of CDS per gene 
echo -e "gene\ttranscript_ref\tCDS_nb_ref" > CDS_nb_per_gene_ref.csv

for gene in $(cat genes_list_ref.txt) ; do
	gene_id_ref=$(grep "=${gene};" ${GFF_REF} | cut -f9 | cut -f1 -d";" | cut -f2 -d":")
	nb_transcript_ref=$(grep -w "${gene_id_ref}" ${GFF_REF} | grep -c $'mRNA\t')
	echo -e "${gene}\t${nb_transcript_ref}" >> transcripts_nb_ref.csv
	id_transcript_ref=$(grep -w "${gene_id_ref}" ${GFF_REF} | grep $'mRNA\t' | cut -f9 | cut -f1 -d';' | cut -f2 -d':')
	nb_cds_ref=$(grep ${id_transcript_ref} ${GFF_REF} | grep -c $'CDS\t')
	echo -e "${gene}\t${id_transcript_ref}\t${nb_cds_ref}" >> CDS_nb_per_gene_ref.csv ;
done

