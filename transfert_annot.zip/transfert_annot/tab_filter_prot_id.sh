#! /bin/bash

# input files

GENE=$1
SP_REF=$2

# script

echo -e "${SP_REF}\t1\t1" >> ${GENE}_prot_id.csv
for sp in $(cat ~/Primates/Gene_alignments/genes_info/${GENE}_sp_list.txt) ; do
gene_id=$(grep "=${GENE};" ~/Primates/GFF_files/${sp}/${sp}_genome_annotation.gff | cut -f9 | cut -f1 -d";" | cut -f2 -d":" | sort | head -1)
mRNA=$(grep -w "${gene_id}" ~/Primates/GFF_files/${sp}/${sp}_genome_annotation.gff | grep $'mRNA\t' | cut -f9)
prot_id=$(echo ${mRNA} | grep -o 'protein_identity=[^;]*' | cut -f2 -d'=')
dna_id=$(echo ${mRNA} | grep -o 'dna_identity=[^;]*' | cut -f2 -d'=')
echo -e "${sp}\t${prot_id}\t${dna_id}" >> ${GENE}_prot_id.csv ;
done


