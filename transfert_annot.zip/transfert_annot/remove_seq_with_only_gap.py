## install packages ###
from Bio import SeqIO
import sys

## arguments ###

    # message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 3:
    sys.exit("ERROR : need 2 arguments : [1] input fasta file [2] output fasta file")
    # recuperer les arguments
in_fasta_file = sys.argv[1]
out_fasta_file = sys.argv[2]

## script ###

with open(out_fasta_file, 'w') as out: # open the fasta file to write seq
    for seq_read in SeqIO.parse(in_fasta_file, 'fasta'): # for each seq of the input fasta file
        sp = seq_read.id
        seq = seq_read.seq
        seq_len = len(seq)
        print(seq_len)
        if seq_read.seq.count('-') != seq_len: # if the sequence is not only gaps
            out.write(f'>{sp}\n') # write the id of the seq in the out fasta file
            out.write(f'{seq}\n') # write the seq in the out fasta file
