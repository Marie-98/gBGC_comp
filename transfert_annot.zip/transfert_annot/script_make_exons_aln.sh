cd ~/Primates
mkdir Gene_alignments
cd Gene_alignments
mkdir genes_info
cd genes_info

## list the genes -> genes with at least 4 species

# list of sp for each gene & tab of sp nb per gene
		# hominoides
for gene in $(cat ~/Primates/GFF_files/Homo_sapiens/genes_list_ref.txt); do
  echo "Homo_sapiens" > ${gene}_sp_list.txt
  for sp in $(cat ~/Primates/Annotation_transfert/Hominoidae_sp_list.txt); do
    pres_gene=$(grep -c "=${gene};" ~/Primates/GFF_files/${sp}/${sp}_genome_annotation.gff)
    if [ "${pres_gene}" != 0 ]; then
      gene_id=$(grep "=${gene};" ~/Primates/GFF_files/${sp}/${sp}_genome_annotation.gff | cut -f9 | cut -f1 -d";" | cut -f2 -d":" | sort | head -1)
      transcrit_id=$(grep -w "${gene_id}" ~/Primates/GFF_files/${sp}/${sp}_genome_annotation.gff | grep $'mRNA\t' | cut -f9 | cut -f1 -d';' | cut -f2 -d':')
      presence=$(grep -w "${transcrit_id}" ~/Primates/GFF_files/${sp}/${sp}_genome_annotation.gff | grep -c $'CDS\t')
      if [ "${presence}" != 0 ]; then
        echo -e "${sp}" >> ${gene}_sp_list.txt
      fi
    fi
  done
  nb_sp=$(wc -l < ${gene}_sp_list.txt)
  echo -e "${gene}\t${nb_sp}" >> tab_nb_sp_per_gene.csv
done

		# cerco
for gene in $(cat ~/Primates/GFF_files/Macaca_mulatta/genes_list_ref.txt); do
  echo "Macaca_mulatta" > ${gene}_sp_list.txt
  for sp in $(cat ~/Primates/Annotation_transfert/Cerco_sp_list.txt); do
    pres_gene=$(grep -c "=${gene};" ~/Primates/GFF_files/${sp}/${sp}_genome_annotation.gff)
    if [ "${pres_gene}" != 0 ]; then
      gene_id=$(grep "=${gene};" ~/Primates/GFF_files/${sp}/${sp}_genome_annotation.gff | cut -f9 | cut -f1 -d";" | cut -f2 -d":" | sort | head -1)
      transcrit_id=$(grep -w "${gene_id}" ~/Primates/GFF_files/${sp}/${sp}_genome_annotation.gff | grep $'mRNA\t' | cut -f9 | cut -f1 -d';' | cut -f2 -d':')
      presence=$(grep -w "${transcrit_id}" ~/Primates/GFF_files/${sp}/${sp}_genome_annotation.gff | grep -c $'CDS\t')
      if [ "${presence}" != 0 ]; then
        echo -e "${sp}" >> ${gene}_sp_list.txt
      fi
    fi
  done
  nb_sp=$(wc -l < ${gene}_sp_list.txt)
  echo -e "${gene}\t${nb_sp}" >> tab_nb_sp_per_gene.csv
done


# list of genes with at least 4 species

LC_ALL=en_US awk '{if ($2>=4) {print $1}}' tab_nb_sp_per_gene.csv > list_genes_min_4sp.txt


## make the fasta file of each gene sequence
cd ../
mkdir genes_seq
cd genes_seq

cat ../genes_info/list_genes_min_4sp.txt | parallel -j15 ~/scripts/script_gene_seq.sh {} 2>error_2.txt >out_2.txt


# check
for GENE in $(cat ../genes_info/list_genes_min_4sp.txt); do
nb_sp_faites=$(grep -c ">" ${GENE}_seq.fasta);
nb_sp_att=$(grep -w "${GENE}" ../genes_info/tab_nb_sp_per_gene.csv | cut -f2);
echo -e "${GENE}\t${nb_sp_faites}\t${nb_sp_att}" >> check_genes_seq.txt;
done


## sorting according to protein and dna identities
cat ~/Primates/Gene_alignments/genes_info/list_genes_min_4sp.txt | parallel -j60 ~/scripts/tab_filter_prot_id.sh {} 2>error.txt >out.txt

for GENE in $(cat ~/Primates/Gene_alignments/genes_info/list_genes_min_4sp.txt); do
echo "Homo_sapiens" > ${GENE}_filter_sp_list.txt ;
LC_ALL=en_US awk '$2>0.8 && $3>0.8 {print $1}' ${GENE}_prot_id.csv >> ${GENE}_filter_sp_list.txt ;
done

cd ~/Primates/Gene_alignments/
mkdir genes_filter_seq
cd genes_filter_seq/

cat ~/Primates/Gene_alignments/genes_info/list_genes_min_4sp.txt | parallel -j50 ~/scripts/get_filter_seq.sh {} 2>error.txt >out.txt

## Align the gene sequences with MACSE
cd ../
mkdir align_genes_seq
cd align_genes_seq

cat ../genes_info/list_genes_min_4sp.txt | parallel -j50 java -jar ~/bin/macse_v2.06.jar -prog alignSequences -seq ../genes_filter_seq/{}_filter_seq.fasta -out_NT {}_seq_align_NT.fasta -out_AA {}_seq_align_AA.fasta 2> error_aln.txt >out_aln.txt


## make one aln fasta file per exon
cd ../
mkdir pos_exons_in_gene_align
cd pos_exons_in_gene_align
cat ../genes_info/list_genes_min_4sp.txt | parallel -j50 python3 ~/scripts/get_final_positions_of_exons_in_gene_aln.py {} ../genes_seq/{}_cds_positions_Homo_sapiens.csv ../align_genes_seq/{}_seq_align_NT.fasta 2> error.txt >out.txt
cd ../

mkdir align_exons_seq
cd align_exons_seq

cat ../genes_info/list_genes_min_4sp.txt | parallel -j50 ~/scripts/script_cut_exon_aln.sh {} ../pos_exons_in_gene_align/{}_cds_final_pos.csv 2> error.txt >out.txt

ls | grep fasta > align_exons_files.txt

mkdir align_exons_seq_corrected
cd align_exons_seq_corrected

cat ../align_exons_files.txt | parallel -j50 python3 ~/scripts/remove_seq_with_only_gap.py ../{} corrected_{}

ls | grep fasta > corrected_align_exons_files.txt

mkdir phase_ok
cd phase_ok

cat ../corrected_align_exons_files.txt | parallel -j50 java -jar ~/bin/macse_v2.06.jar -prog alignSequences -seq ../{} -out_NT {} -out_AA AA_{} 2> error_aln_exon.txt >out_aln_exon.txt








