cd ~/Primates/Gene_alignments/align_exons_seq/align_exons_seq_corrected/phase_ok
find -maxdepth 1 -type f -name "corrected*NT.fasta" | cut -f2 -d'/' > list_files_aln.txt
mkdir not_used
for file in $(cat list_files_aln.txt); do
	len=$(seqkit fx2tab --length --name  $file | cut -f2 | head -1)
	if (( ${len} < 100 )); then
		mv $file not_used 
	fi
done

for file in $(cat list_files_aln.txt); do
	nb_sp=$(grep -c ">" $file)
	if (( ${nb_sp} < 4 )); then
		mv $file not_used 
	fi
done
