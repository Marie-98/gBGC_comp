## install packages ###
import sys
import pandas as pd
from Bio import SeqIO
import numpy as np

# message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 4:
    sys.exit("ERROR : need 3 arguments : [1]gene name [2]table of cds positions [3]gene_alignment [4] reference species")
# recuperer les arguments
gene_name = sys.argv[1]
tab_cds_pos_name = sys.argv[2]
gene_align_file = sys.argv[3]
sp_ref = sys.argv[4]

## script ###

tab_cds_pos = pd.read_csv(tab_cds_pos_name, sep="\t", header=None)
tab_cds_pos.columns = ["start", "end"]

#print(tab_cds_pos.head())

exon_end_pos = tab_cds_pos["end"] - tab_cds_pos["start"]
#print(exon_end_pos)

exons_nb = len(tab_cds_pos)
#print(exons_nb)

for seq_read in SeqIO.parse(gene_align_file, "fasta"):
    if seq_read.id == sp_ref:
        seq = seq_read.seq
seq_list = list(seq)

final_start_pos = [0]*exons_nb
final_end_pos = []

for exon in range(1,exons_nb+1):
   # print(exon)
   # print(seq_list)
    end_pos = exon_end_pos[exon-1]
    #print(end_pos)
    for i in range(0,len(seq_list)):
        if seq_list[i] not in ["A","C","G","T","N"]:
            end_pos += 1
        if i==end_pos:
            final_end_pos.append(end_pos)
           # print(end_pos)
           # print(seq_list[0:end_pos+1])
            del seq_list[0:end_pos+1]
            break
            
#print(final_start_pos)
#print(final_end_pos)

tab_final_pos = pd.DataFrame({"start":final_start_pos,
				"end":final_end_pos})

tab_final_pos = tab_final_pos + 1	
tab_final_pos["end"] = np.cumsum(tab_final_pos["end"])	

for i in range(1,len(tab_final_pos+1)):
    tab_final_pos["start"][i] = tab_final_pos["end"][i-1]+1
		
#print(tab_final_pos)

tab_final_pos.to_csv(gene_name + '_cds_final_pos.csv', index=False)


