#! /bin/bash

# input files

GENE=$1

# script

seqkit grep  -n -f ~/Primates/Filter_prot_id/${GENE}_filter_sp_list.txt ~/Primates/Gene_alignments/genes_seq/${GENE}_seq.fasta -o ${GENE}_filter_seq_ref_dupl.fasta

seqkit rmdup -n ${GENE}_filter_seq_ref_dupl.fasta -o ${GENE}_filter_seq.fasta
