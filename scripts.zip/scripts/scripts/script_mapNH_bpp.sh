#! /bin/bash

### mapping substitutions ###

# work with bio++ V3 https://biopp.github.io/ 

# we are going to use a mapping method : https://github.com/BioPP/testnh  & https://github.com/BioPP/bppsuite/


# parametres ###

TRIBE=$1
EXON=$2

# script ###

# recuperer nom gene et position exon (pour le nom du fichier d'alignement)

GENE=$(grep -w ${EXON} ~/Murinae/Reference_exons/Gene_exons_ref_list.txt | cut -f1)

EXON_POSITION=$(grep -w ${EXON} ~/Murinae/Reference_exons/Gene_exons_ref_list.txt | cut -f3)

# Data set

ALIGN_SEQ_FILE="\/home\/mriffis\/Murinae\/${TRIBE}\/Aligned_Sequences\/FINAL\/${GENE}_${EXON}_${EXON_POSITION}_FINAL_align_NT.fasta"

TREE_FILE="\/home\/mriffis\/Murinae\/${TRIBE}\/Phylogeny\/gene_tree\/${GENE}_tree.treefile"

# 1 ## Put the name of the data set in the parameter file

# create parameter files for the exon

cp ~/bin/mapNH/bppML.bpp ./bppML_${EXON}.bpp
cp ~/bin/mapNH/mapNH.bpp ./mapNH_${EXON}.bpp

# replace the arguments

sed -i "s/seqname/${ALIGN_SEQ_FILE}/" bppML_${EXON}.bpp
sed -i "s/exonname/${EXON}/" bppML_${EXON}.bpp
sed -i "s/treename/${TREE_FILE}/" bppML_${EXON}.bpp

sed -i "s/seqname/${ALIGN_SEQ_FILE}/" mapNH_${EXON}.bpp
sed -i "s/exonname/${EXON}/" mapNH_${EXON}.bpp

# 2 ## Fit a homogeneous model

~/bin/mapNH/bppML  param=bppML_${EXON}.bpp

# 3 ## Run mapNH

~/bin/mapNH/mapnh param=mapNH_${EXON}.bpp


# delete the parameter files

rm bppML_${EXON}.bpp mapNH_${EXON}.bpp
