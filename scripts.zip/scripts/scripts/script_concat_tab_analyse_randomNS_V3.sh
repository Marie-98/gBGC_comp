mkdir tab_all_genes

for file in *_tab_NS_WS_after_epNS_with_random.csv ; do sed 1d $file ; done > tab_all_genes/tab_NS_WS_after_epNS_with_random.csv
for file in *_tab_NS_SW_after_epNS_with_random.csv ; do sed 1d $file ; done > tab_all_genes/tab_NS_SW_after_epNS_with_random.csv
for file in *_tab_NS_SS_after_epNS_with_random.csv ; do sed 1d $file ; done > tab_all_genes/tab_NS_SS_after_epNS_with_random.csv
for file in *_tab_NS_WW_after_epNS_with_random.csv ; do sed 1d $file ; done > tab_all_genes/tab_NS_WW_after_epNS_with_random.csv

for file in *_tab_NS_WS_after_epnoNS_with_random.csv ; do sed 1d $file ; done > tab_all_genes/tab_NS_WS_after_epnoNS_with_random.csv
for file in *_tab_NS_SW_after_epnoNS_with_random.csv ; do sed 1d $file ; done > tab_all_genes/tab_NS_SW_after_epnoNS_with_random.csv
for file in *_tab_NS_SS_after_epnoNS_with_random.csv ; do sed 1d $file ; done > tab_all_genes/tab_NS_SS_after_epnoNS_with_random.csv
for file in *_tab_NS_WW_after_epnoNS_with_random.csv ; do sed 1d $file ; done > tab_all_genes/tab_NS_WW_after_epnoNS_with_random.csv

for file in *_tab_NS_WS_during_epNS_otherex.csv ; do sed 1d $file ; done > tab_all_genes/tab_NS_WS_during_epNS_otherexons.csv
for file in *_tab_NS_SW_during_epNS_otherex.csv ; do sed 1d $file ; done > tab_all_genes/tab_NS_SW_during_epNS_otherexons.csv
for file in *_tab_NS_SS_during_epNS_otherex.csv ; do sed 1d $file ; done > tab_all_genes/tab_NS_SS_during_epNS_otherexons.csv
for file in *_tab_NS_WW_during_epNS_otherex.csv ; do sed 1d $file ; done > tab_all_genes/tab_NS_WW_during_epNS_otherexons.csv

for file in *_tab_NS_WS_during_epnoNS_otherex.csv ; do sed 1d $file ; done > tab_all_genes/tab_NS_WS_during_epnoNS_otherexons.csv
for file in *_tab_NS_SW_during_epnoNS_otherex.csv ; do sed 1d $file ; done > tab_all_genes/tab_NS_SW_during_epnoNS_otherexons.csv
for file in *_tab_NS_SS_during_epnoNS_otherex.csv ; do sed 1d $file ; done > tab_all_genes/tab_NS_SS_during_epnoNS_otherexons.csv
for file in *_tab_NS_WW_during_epnoNS_otherex.csv ; do sed 1d $file ; done > tab_all_genes/tab_NS_WW_during_epnoNS_otherexons.csv

for file in *_tab_NS_WS_after_epNS_otherex.csv ; do sed 1d $file ; done > tab_all_genes/tab_NS_WS_after_epNS_otherexons.csv
for file in *_tab_NS_SW_after_epNS_otherex.csv ; do sed 1d $file ; done > tab_all_genes/tab_NS_SW_after_epNS_otherexons.csv
for file in *_tab_NS_SS_after_epNS_otherex.csv ; do sed 1d $file ; done > tab_all_genes/tab_NS_SS_after_epNS_otherexons.csv
for file in *_tab_NS_WW_after_epNS_otherex.csv ; do sed 1d $file ; done > tab_all_genes/tab_NS_WW_after_epNS_otherexons.csv

for file in *_tab_NS_WS_after_epnoNS_otherex.csv ; do sed 1d $file ; done > tab_all_genes/tab_NS_WS_after_epnoNS_otherexons.csv
for file in *_tab_NS_SW_after_epnoNS_otherex.csv ; do sed 1d $file ; done > tab_all_genes/tab_NS_SW_after_epnoNS_otherexons.csv
for file in *_tab_NS_SS_after_epnoNS_otherex.csv ; do sed 1d $file ; done > tab_all_genes/tab_NS_SS_after_epnoNS_otherexons.csv
for file in *_tab_NS_WW_after_epnoNS_otherex.csv ; do sed 1d $file ; done > tab_all_genes/tab_NS_WW_after_epnoNS_otherexons.csv


