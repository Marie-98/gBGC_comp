#!/usr/bin/env Rscript

## Arguments ###
args = commandArgs(trailingOnly=TRUE)
print(args)

if (length(args)<3) {
  stop("3 arguments must be supplied : [1] input tree (newick format) [2] outgroup, [3] name of the rooted phylogeny", call.=FALSE)
}

tree = args[1] # complete phylogeny
outgroup = args[2] # outgroup
rooted_tree = args[3] # name of the rooted phylogeny

## load packages ###
library(ape)

## script ###

# read the phylogeny
phylo <- read.tree(file = tree)

# root the phylogeny
rooted_phylo <- root(phylo, outgroup = outgroup, resolve.root = T)

# save this rooted phylogeny
ape::write.tree(rooted_phylo, file=rooted_tree)
