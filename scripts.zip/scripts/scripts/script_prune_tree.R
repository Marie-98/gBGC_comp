#!/usr/bin/env Rscript

## Arguments ###
args = commandArgs(trailingOnly=TRUE)
print(args)

if (length(args)<3) {
  stop("3 arguments must be supplied : [1] input tree [2] alignment [3] output tree name", call.=FALSE)
}

tree = args[1] # complete phylogeny
alignment = args[2] # alignment of a exon with N species
out_tree_name = args[3] # name of the pruned tree wich will contains only the N species present in the exon alignment

## load packages ###
library(ape)

## script ###

# read the phylogeny
phylo <- read.tree(file = tree)

# get the list of the species present in the exon alignment
align <- read.dna(alignment, format = 'fasta')
sp_list <- labels(align)

# get the pruned phylogeny with only those species
pruned_phylo <- keep.tip(phylo,sp_list)

# save this pruned phylogeny
ape::write.tree(pruned_phylo, file=out_tree_name)
