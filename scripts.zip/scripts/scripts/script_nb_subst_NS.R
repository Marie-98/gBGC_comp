#!/usr/bin/env Rscript

## Arguments ##################################################################################
args = commandArgs(trailingOnly=TRUE)
print(args)

if (length(args)<3) {
  stop("3 arguments must be supplied : [1] exon name [2] path of the directory of the mapping substitutions tables [3] name of the csv out", call.=FALSE)
}

exon_name = args[1]
dir_path = args[2]
csv_out = args[3]

# test ####
#exon_name = "ENSMUSE00001335942"
#dir_path = "./"
###########

## script ####################################################################################

# load tables
tab_WS <- read.table(paste0(dir_path, exon_name, "_counts_dN_X_WS.csv"), sep="\t", header=T, check.names = F)
tab_WS <- tab_WS[,2:ncol(tab_WS)]

tab_SW <- read.table(paste0(dir_path, exon_name, "_counts_dN_X_SW.csv"), sep="\t", header=T, check.names = F)
tab_SW <- tab_SW[,2:ncol(tab_SW)]

tab_WW <- read.table(paste0(dir_path, exon_name, "_counts_dN_X_WW.csv"), sep="\t", header=T, check.names = F)
tab_WW <- tab_WW[,2:ncol(tab_WW)]

tab_SS <- read.table(paste0(dir_path, exon_name, "_counts_dN_X_SS.csv"), sep="\t", header=T, check.names = F)
tab_SS <- tab_SS[,2:ncol(tab_SS)]

# total number of WS substitutions in a branch
nb_subst_WS <- colSums(tab_WS)
nb_subst_SW <- colSums(tab_SW)
nb_subst_WW <- colSums(tab_WW)
nb_subst_SS <- colSums(tab_SS)

# build the table
branches <- colnames(tab_WS)
tab_final <- as.data.frame(cbind(branches, nb_subst_WS, nb_subst_SW, nb_subst_WW, nb_subst_SS))
tab_final$branches <- as.numeric(as.character(tab_final$branches))
tab_final$nb_subst_WS <- as.numeric(as.character(tab_final$nb_subst_WS))
tab_final$nb_subst_SW <- as.numeric(as.character(tab_final$nb_subst_SW))
tab_final$nb_subst_WW <- as.numeric(as.character(tab_final$nb_subst_WW))
tab_final$nb_subst_SS <- as.numeric(as.character(tab_final$nb_subst_SS))

# save the table
write.table(tab_final, csv_out, sep="\t", quote = F, row.names = F)
