#!/usr/bin/env Rscript

args = commandArgs(trailingOnly=TRUE)
print(args)

if (length(args)<1) {
  stop("1 arguments must be supplied : [1] path to the tab of trees lengths for the supplementary filter of paralogs", call.=FALSE)
}

tab_path = args[1]

library(tidyr)

tab <- read.table(tab_path, header=F, sep="\t")
colnames(tab) <- c("gene", "exon","lg_seq","lg_arbre_G", "lg_arbre_E")
tab <-tab %>% drop_na()

tab$LGsurLE <- tab$lg_arbre_G/tab$lg_arbre_E

tab_1.5 <- tab[tab$LGsurLE > 1.5, ]

paralog_exons <- tab_1.5$exon

write.table(tab,file="monfichierexport",sep=";",col.names=F,row.names=F, quote=F)
