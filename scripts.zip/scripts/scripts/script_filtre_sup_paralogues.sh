#! /bin/bash

# Arguments ###

EXON=$1
TRIBE=$2

# Script ###

# recuperer nom gene
GENE=$(grep -w ${EXON} ~/Murinae/Reference_exons/Gene_exons_ref_list.txt | cut -f1)
POS=$(grep -w ${EXON} ~/Murinae/Reference_exons/Gene_exons_ref_list.txt | cut -f3)

# arbre global : forcer topologie et obtenir longueurs branches avec iqtree
iqtree2 -s ~/Murinae/${TRIBE}/Aligned_Sequences/FINAL/${GENE}_${EXON}_${POS}_FINAL_align_NT.fasta  -nt 1 -m GTR -keep-ident -g ~/Murinae/${TRIBE}/Phylogeny/gene_tree/${GENE}_tree.treefile --prefix ${GENE}_${EXON}_tree_g >out_iqtree_global_${EXON}.txt 2>error_iqtree_global_${EXON}.txt

# arbre exon avec iqtree
iqtree2 -s ~/Murinae/${TRIBE}/Aligned_Sequences/FINAL/${GENE}_${EXON}_${POS}_FINAL_align_NT.fasta  -nt 1 -m GTR --prefix ${GENE}_${EXON}_tree_e >out_iqtree_exon_${EXON}.txt 2>error_iqtree_exon_${EXON}.txt

# calculer longueur tot arbre global
python3 ~/scripts/lg_tree.py ~/Murinae/${TRIBE}/Sup_filter_paralogs/${GENE}_${EXON}_tree_g.treefile lg_tree_g_${EXON}.txt >out_lg_tot_tree_g_${EXON}.txt 2>error_lg_tot_tree_g_${EXON}.txt
lg_tree_g=$(cat lg_tree_g_${EXON}.txt)

# calculer longueur tot arbre exon
python3 ~/scripts/lg_tree.py ~/Murinae/${TRIBE}/Sup_filter_paralogs/${GENE}_${EXON}_tree_e.treefile lg_tree_e_${EXON}.txt >out_lg_tot_tree_e_${EXON}.txt 2>error_lg_tot_tree_e_${EXON}.txt
lg_tree_e=$(cat lg_tree_e_${EXON}.txt)

# recuperer longueur de la sequence
lg=$(grep ${EXON} ~/Murinae/${TRIBE}/Aligned_Sequences/FINAL/align_len.csv | cut -f2)

# faire tableau
echo -e "${GENE}\t${EXON}\t${lg}\t${lg_tree_g}\t${lg_tree_e}"

