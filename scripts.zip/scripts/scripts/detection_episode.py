## Install packages ###
import sys
import pandas as pd
import os

## arguments ###

 # message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 6:
    sys.exit("ERROR : need 5 arguments : [1]table with names and lengths of the exons (gene, exon, position, length) [2]directory of the tables of the signif of stat [3]threshold length of seq [4]seuil signif [5]name of the csv out file")
    # recuperer les arguments
tab_exons_lg_seq_name = sys.argv[1]
tab_signif_dir = sys.argv[2]
threshold_lg_seq = sys.argv[3]
seuil_signif = sys.argv[4]
out_file_name = sys.argv[5]

## script ###

threshold_lg_seq = int(threshold_lg_seq)
seuil_signif = int(seuil_signif)

# read the table of lengths of exons seq
tab_lg_seq = pd.read_csv(tab_exons_lg_seq_name, sep="\t", header=None)
tab_lg_seq.columns = ["Gene", "Exon", "Position", "Longueur_Seq"]

# make the exons list of the gene
exons_list = list(tab_lg_seq['Exon'])

# prepare the columns of the final table
all_exon_col = []
all_branches_col = []
all_episode_col = []

# count exons with presence of signif table
exons_ok = 0

# for each exon
for exon in exons_list:
    # read the table of the signif of stat
    tab_signif_name = tab_signif_dir + exon + "_tab_signif_stat.csv"
    if os.path.exists(tab_signif_name):
        tab_signif = pd.read_csv(tab_signif_name, sep=",")
        branches = list(tab_signif['branches'])
        exons_ok = exons_ok + 1
    # get the length of the sequence
    seq_lg = tab_lg_seq[tab_lg_seq['Exon'] == exon]['Longueur_Seq'].iloc[0]
    Episode = []
    if os.path.exists(tab_signif_name):
        for br in branches:
        # define if episode is yes or no
            if seq_lg <= threshold_lg_seq:
                if tab_signif[tab_signif['branches'] == br]['signif_nb_WS'].iloc[0] >= seuil_signif:
                    Episode.append('YES')
                elif tab_signif[tab_signif['branches'] == br]['signif_nb_WS'].iloc[0] < 700:
                    Episode.append('SURENO')
                else:
                    Episode.append('NO')    
            else:
                if tab_signif[tab_signif['branches'] == br]['signif_nb_WS'].iloc[0] >= seuil_signif and  tab_signif[tab_signif['branches'] == br]['signif_I'].iloc[0] >= seuil_signif:
                    Episode.append('YES')
                elif tab_signif[tab_signif['branches'] == br]['signif_nb_WS'].iloc[0] < 700 and  tab_signif[tab_signif['branches'] == br]['signif_I'].iloc[0] < 700:
                    Episode.append('SURENO')
                else:
                    Episode.append('NO')
        # fill the columns of the final table
        exon_col = [exon] * len(branches)
        all_exon_col = all_exon_col + exon_col
        all_branches_col = all_branches_col + branches
        all_episode_col = all_episode_col + Episode


if exons_ok > 0:
    # make the final table
    tab = pd.DataFrame({
        "Exon": all_exon_col,
        "Branches": all_branches_col,
        "Episode": all_episode_col
    })

    # save this table
    tab.to_csv(out_file_name, index=False)
