## install packages ###
import sys
import pandas as pd
import numpy as np
import random

## arguments ###

 # message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 5:
    sys.exit("ERROR : need 4 arguments : [1]path to the table of stat number of substitutions [2]path to the table of the number and length of the branches [3]name of the csv out file [4]number of simulations")
    # recuperer les arguments
tab_nb_subst = sys.argv[1]
tab_num_len_br = sys.argv[2]
out_file = sys.argv[3]
nb_simul = sys.argv[4]

## script ###

## read the tables ####
tab_nb_subst_pd = pd.read_csv(tab_nb_subst, sep="\t")
#print(tab_nb_subst_pd.head())
tab_num_len_br_pd = pd.read_csv(tab_num_len_br, sep=",")
#print(tab_num_len_br_pd.head())

## get total number of substitution in all branches ####
nb_subst_WS_tot = np.sum(tab_nb_subst_pd['nb_subst_WS'])
nb_subst_WS_tot = round(nb_subst_WS_tot)
nb_subst_SW_tot = np.sum(tab_nb_subst_pd['nb_subst_SW'])
nb_subst_SW_tot = round(nb_subst_SW_tot)
print(nb_subst_WS_tot)
print(nb_subst_SW_tot)

## get numero and length of the branches, and number of branches ####
num_br = list(tab_num_len_br_pd['num'])
#print(num_br)
len_br = list(tab_num_len_br_pd['lg'])
#print(len_br)
nb_br = len(num_br)
#print(nb_br)

## get the cumul length of the branches ####
cum_len_br = np.cumsum(len_br)
#print(cum_len_br)
proba_cum_len_br = cum_len_br/cum_len_br[-1]
#print(proba_cum_len_br[0])
#print(proba_cum_len_br[nb_br-1])

## simul the distribution of substitutions WS in the tree ####
tab_simul_distrib_subst = pd.DataFrame(list(zip(num_br)))
#print(tab_simul_distrib_subst.head())
for simul in range(1, int(nb_simul)+1):
    simul_subst_br_WS = [0] * nb_br
    for subst in range(1, nb_subst_WS_tot+1):
        proba = random.random()
        for br in range(0, nb_br):
            if proba <= proba_cum_len_br[br]:
                simul_subst_br_WS[br] = simul_subst_br_WS[br] + 1
                break
    tab_simul_subst_br = pd.DataFrame(list(zip(simul_subst_br_WS)))
    tab_simul_distrib_subst = pd.concat([tab_simul_distrib_subst,tab_simul_subst_br], axis=1)

## simul the distribution of substitutions SW in the tree ####
#simul_subst_br_SW = [0] * nb_br
#for subst in range(1, nb_subst_SW_tot+1):
#    proba = random.random()
#    for br in range(0, nb_br):
#        if proba <= proba_cum_len_br[br]:
#            simul_subst_br_SW[br] = simul_subst_br_SW[br] + 1
#            break

#tab_simul_distrib_subst = pd.DataFrame(list(zip(num_br, simul_subst_br_WS, simul_subst_br_SW)), columns = ['branches', 'nb_subst_WS', 'nb_subst_SW'])
#print(tab_simul_distrib_subst)

col_simul = list((range(1, int(nb_simul)+1)))
col_simul = ["branches"] + col_simul
tab_simul_distrib_subst.columns = col_simul
tab_simul_distrib_subst.to_csv(out_file, index=False)
