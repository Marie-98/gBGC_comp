#! /bin/bash

# Arguments ###

EXON=$1
TRIBE=$2

# Script ###

GENE=$(grep -w ${EXON} ~/Murinae/Reference_exons/gene_exons_position_ref_all.csv | cut -f1)
POS=$(grep -w ${EXON} ~/Murinae/Reference_exons/gene_exons_position_ref_all.csv | cut -f3)

python3 ~/scripts/GC_content.py $EXON ~/Murinae/${TRIBE}/Aligned_Sequences/FINAL/${GENE}_${EXON}_${POS}_FINAL_align_NT.fasta ${EXON}_GC_content.csv
