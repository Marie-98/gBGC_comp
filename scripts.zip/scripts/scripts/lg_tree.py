from ete3 import Tree
import sys

## arguments ###

 # message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 3:
    sys.exit("ERROR : need 2 arguments : [1]path to the tree of the gene [2]out file name")
    # recuperer les arguments
tree_name = sys.argv[1]
out_file_name = sys.argv[2]

## script ###

# read the tree
t = Tree(tree_name, format=1)

# get the branches lengths

lg_list = []
# for each node of the tree :
for node in t.iter_descendants("postorder"):
    lg = node.dist
    lg_list.append(lg)
#print(lg_list)
sum_lg = sum(lg_list)
with open(out_file_name, 'w') as out:
    out.write(f'{sum_lg}')

