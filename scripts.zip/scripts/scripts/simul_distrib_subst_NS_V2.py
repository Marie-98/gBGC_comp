## install packages ###
import sys
import pandas as pd
import numpy as np
import random

## arguments ###

 # message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 6:
    sys.exit("ERROR : need 5 arguments : [1]path to the table of episodes detection [2]path to the table of stat number of substitutions NS [3]path to the table of the number and length of the branches [4]exon name [5]number of simulations")
    # recuperer les arguments
tab_ep_detection = sys.argv[1]
tab_nb_subst = sys.argv[2]
tab_num_len_br = sys.argv[3]
exon_name = sys.argv[4]
nb_simul = sys.argv[5]

## script ###

## read the tables ####
tab_nb_subst_pd = pd.read_csv(tab_nb_subst, sep="\t")
print(tab_nb_subst_pd.head())
tab_ep = pd.read_csv(tab_ep_detection, sep=",")
print(tab_ep.head())
tab_num_len_br_pd = pd.read_csv(tab_num_len_br, sep=",")
print(tab_num_len_br_pd.head())

## get the num of branches without episodes (SURENO)
tab_ep_exon = tab_ep[tab_ep['Exon'] == exon_name]
print(tab_ep_exon.head())
tab_ep_exon_br_noep = tab_ep_exon[(tab_ep_exon['Episode'] == 'SURENO') | (tab_ep_exon['Episode'] == 'NO')]
print(tab_ep_exon_br_noep.head())
br_noep = list(tab_ep_exon_br_noep['Branches'])
print(br_noep)

## get the tab of nb subst for just the branches without episodes
tab_nb_subst_noep = tab_nb_subst_pd[tab_nb_subst_pd['branches'].isin(br_noep)]

## round the nb of subst
list_nb_subst_WS = list(tab_nb_subst_noep['nb_subst_WS'])
list_nb_subst_WS_round = np.round(np.array(list_nb_subst_WS))
list_nb_subst_SW = list(tab_nb_subst_noep['nb_subst_SW'])
list_nb_subst_SW_round = np.round(np.array(list_nb_subst_SW))
list_nb_subst_SS = list(tab_nb_subst_noep['nb_subst_SS'])
list_nb_subst_SS_round = np.round(np.array(list_nb_subst_SS))
list_nb_subst_WW = list(tab_nb_subst_noep['nb_subst_WW'])
list_nb_subst_WW_round = np.round(np.array(list_nb_subst_WW))

## get total number of substitution in all branches ####
nb_subst_WS_tot = int(np.sum(list_nb_subst_WS_round))
nb_subst_SW_tot = int(np.sum(list_nb_subst_SW_round))
nb_subst_SS_tot = int(np.sum(list_nb_subst_SS_round))
nb_subst_WW_tot = int(np.sum(list_nb_subst_WW_round))
print(nb_subst_WS_tot)
print(nb_subst_SW_tot)
print(nb_subst_SS_tot)
print(nb_subst_WW_tot)

## get the tab of num and lenght of branches for just the branches without episodes
tab_num_len_br_noep = tab_num_len_br_pd[tab_num_len_br_pd['num'].isin(br_noep)]

## get numero and length of the branches, and number of branches ####
num_br = list(tab_num_len_br_noep['num'])

len_br = list(tab_num_len_br_noep['lg'])
print(len_br)

nb_br = len(num_br)


## get the cumul length of the branches ####
cum_len_br = np.cumsum(len_br)
print(cum_len_br)
proba_cum_len_br = cum_len_br/cum_len_br[-1]
print(proba_cum_len_br)

## simul the distribution of substitutions WS in the tree ####
tab_simul_distrib_subst_WS = pd.DataFrame(list(zip(num_br)))
for simul in range(1, int(nb_simul)+1):
    simul_subst_br_WS = [0] * nb_br
    for subst in range(1, nb_subst_WS_tot+1):
        proba = random.random()
        for br in range(0, nb_br):
            if proba <= proba_cum_len_br[br]:
                simul_subst_br_WS[br] = simul_subst_br_WS[br] + 1
                break
    tab_simul_subst_br_WS = pd.DataFrame(list(zip(simul_subst_br_WS)))
    tab_simul_distrib_subst_WS = pd.concat([tab_simul_distrib_subst_WS,tab_simul_subst_br_WS], axis=1)

## simul the distribution of substitutions SW in the tree ####
tab_simul_distrib_subst_SW = pd.DataFrame(list(zip(num_br)))
for simul in range(1, int(nb_simul)+1):
    simul_subst_br_SW = [0] * nb_br
    for subst in range(1, nb_subst_SW_tot+1):
        proba = random.random()
        for br in range(0, nb_br):
            if proba <= proba_cum_len_br[br]:
                simul_subst_br_SW[br] = simul_subst_br_SW[br] + 1
                break
    tab_simul_subst_br_SW = pd.DataFrame(list(zip(simul_subst_br_SW)))
    tab_simul_distrib_subst_SW = pd.concat([tab_simul_distrib_subst_SW,tab_simul_subst_br_SW], axis=1)
    
## simul the distribution of substitutions WW in the tree ####
tab_simul_distrib_subst_WW = pd.DataFrame(list(zip(num_br)))
for simul in range(1, int(nb_simul)+1):
    simul_subst_br_WW = [0] * nb_br
    for subst in range(1, nb_subst_WW_tot+1):
        proba = random.random()
        for br in range(0, nb_br):
            if proba <= proba_cum_len_br[br]:
                simul_subst_br_WW[br] = simul_subst_br_WW[br] + 1
                break
    tab_simul_subst_br_WW = pd.DataFrame(list(zip(simul_subst_br_WW)))
    tab_simul_distrib_subst_WW = pd.concat([tab_simul_distrib_subst_WW,tab_simul_subst_br_WW], axis=1)

## simul the distribution of substitutions SS in the tree ####
tab_simul_distrib_subst_SS = pd.DataFrame(list(zip(num_br)))
for simul in range(1, int(nb_simul)+1):
    simul_subst_br_SS = [0] * nb_br
    for subst in range(1, nb_subst_SS_tot+1):
        proba = random.random()
        for br in range(0, nb_br):
            if proba <= proba_cum_len_br[br]:
                simul_subst_br_SS[br] = simul_subst_br_SS[br] + 1
                break
    tab_simul_subst_br_SS = pd.DataFrame(list(zip(simul_subst_br_SS)))
    tab_simul_distrib_subst_SS = pd.concat([tab_simul_distrib_subst_SS,tab_simul_subst_br_SS], axis=1)

# add columns names (branches and num of simul)
col_simul = list((range(1, int(nb_simul)+1)))
col_simul = ["branches"] + col_simul
tab_simul_distrib_subst_WS.columns = col_simul
tab_simul_distrib_subst_SW.columns = col_simul
tab_simul_distrib_subst_SS.columns = col_simul
tab_simul_distrib_subst_WW.columns = col_simul
# save the tables of subst distrib simul
tab_simul_distrib_subst_WS.to_csv(exon_name + '_simul_distrib_subst_WS_NS.csv', index=False)
tab_simul_distrib_subst_SW.to_csv(exon_name + '_simul_distrib_subst_SW_NS.csv', index=False)
tab_simul_distrib_subst_SS.to_csv(exon_name + '_simul_distrib_subst_SS_NS.csv', index=False)
tab_simul_distrib_subst_WW.to_csv(exon_name + '_simul_distrib_subst_WW_NS.csv', index=False)
