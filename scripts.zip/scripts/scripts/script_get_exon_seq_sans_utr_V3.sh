#! /bin/bash

# parametres ##

EXON=$1 # exon in the list of exons at extremities of genes
EXONS_POSITIONS_LIST=$2 # list of exons at extremities of gene and their position (start, end)
BLAST_UTR_5=$3 # blast 5'UTR seq vs exons ref
BLAST_UTR_3=$4 # blast 3'UTR seq vs exons ref
EXONS_SEQ=$5 # fasta file of exons ref sequences
suppr=${5:-1} # supprimer les fichiers intermediaires : 1 oui ; 2 non ; par défault : 1

# script ##

if [ "$(grep -c ${EXON} ${EXONS_POSITIONS_LIST})" -eq 1 ]; then
	POSITION=$(grep ${EXON} ${EXONS_POSITIONS_LIST} | cut -f2)
	echo -e "${EXON}\t${POSITION}" >> positions.txt

	# exon at start
	if [ $POSITION == "START" ];then

		grep -w "${EXON}" ${BLAST_UTR_5} |\
		awk -v exon=${EXON} '$1 ~ exon && $2 ~ exon {print $0}' > blast_UTR5_${EXON}.txt

		if [ $(wc -l < blast_UTR5_${EXON}.txt) -eq 0 ]; then
			echo -e "${EXON}" >> list_exons_start_sans_seq_UTR5.txt
			blast_utr="notok" ;
		elif [ $(wc -l < blast_UTR5_${EXON}.txt) -gt 1 ]; then
			echo -e "${EXON}" >> list_exons_start_plusieurs_seq_UTR5.txt
			min_evalue=$(sort -g -k3 blast_UTR5_${EXON}.txt | head -1 | cut -f3)
			max_long=$(LC_ALL=en_US awk -v min=${min_evalue} '{if ($3==min) {print $0}}' blast_UTR5_${EXON}.txt | sort -k5 -r | head -1 | cut -f5)
			LC_ALL=en_US awk -v min=${min_evalue} '{if ($3==min) {print $0}}' blast_UTR5_${EXON}.txt | \
			LC_ALL=en_US awk -v max=${max_long} '{if ($5==max) {print $0}}' | \
			sort -k4 -r | head -1 > best_blast_UTR5_${EXON}.txt
			exon_seq_start=$(cut -f11 best_blast_UTR5_${EXON}.txt)
			exon_seq_end=$(cut -f6 best_blast_UTR5_${EXON}.txt)
			blast_length=$(cut -f5 best_blast_UTR5_${EXON}.txt)
			utr_length=$(cut -f7 best_blast_UTR5_${EXON}.txt)
			if [ $(cut -f10 best_blast_UTR5_${EXON}.txt) -eq 1 ]; then
				blast_utr="ok";
			else
				blast_utr="notok";
			fi ;
		else
			exon_seq_start=$(cut -f11 blast_UTR5_${EXON}.txt)
			exon_seq_end=$(cut -f6 blast_UTR5_${EXON}.txt)
			blast_length=$(cut -f5 blast_UTR5_${EXON}.txt)
			utr_length=$(cut -f7 blast_UTR5_${EXON}.txt)
			if [ $(cut -f10 blast_UTR5_${EXON}.txt) -eq 1 ]; then
				blast_utr="ok";
			else
				blast_utr="notok";
			fi ;
		fi
		
		if [ $blast_utr == "ok" ]; then
			grep -w "${EXON}" ${EXONS_SEQ} > ${EXON}_header.txt
			sed -i 's/>//g' ${EXON}_header.txt
			seqkit grep -n -f ${EXON}_header.txt ${EXONS_SEQ} -o ${EXON}_seq.fasta
			echo -e "${EXON}\t${exon_seq_start}\t${exon_seq_end}" >> start_end_exons.txt 
			seqkit subseq -r ${exon_seq_start}:${exon_seq_end} ${EXON}_seq.fasta > ${EXON}_coding_seq.fasta
			grep -v ">" ${EXON}_coding_seq.fasta > ${EXON}_coding_seq_seqonly.txt
			echo -e ">$(cat ${EXON}_header.txt)\n$(cat ${EXON}_coding_seq_seqonly.txt)"
			echo -e "${EXON}\t${utr_length}\t${blast_length}" >> utr_blast_lengths.csv ;
		fi
	
	# exon at end
	else

		grep -w "${EXON}" ${BLAST_UTR_3} |\
		awk -v exon=${EXON} '$1 ~ exon && $2 ~ exon {print $0}' > blast_UTR3_${EXON}.txt

		if [ $(wc -l < blast_UTR3_${EXON}.txt) -eq 0 ]; then
			echo -e "${EXON}" >> list_exons_end_sans_seq_UTR3.txt
			blast_utr="notok" ;
		elif [ $(wc -l < blast_UTR3_${EXON}.txt) -gt 1 ]; then
			echo -e "${EXON}" >> list_exons_end_plusieurs_seq_UTR3.txt
			min_evalue=$(sort -g -k3 blast_UTR3_${EXON}.txt | head -1 | cut -f3)
			max_long=$(LC_ALL=en_US awk -v min=${min_evalue} '{if ($3==min) {print $0}}' blast_UTR3_${EXON}.txt | sort -k5 -r | head -1 | cut -f5)
			LC_ALL=en_US awk -v min=${min_evalue} '{if ($3==min) {print $0}}' blast_UTR3_${EXON}.txt | \
			LC_ALL=en_US awk -v max=${max_long} '{if ($5==max) {print $0}}' | \
			sort -k4 -r | head -1 > best_blast_UTR3_${EXON}.txt
			exon_seq_start=1
			exon_seq_end=$(cut -f10 best_blast_UTR3_${EXON}.txt)
			blast_length=$(cut -f5 best_blast_UTR3_${EXON}.txt)
			utr_length=$(cut -f7 best_blast_UTR3_${EXON}.txt)
			if (( "$(cut -f11 best_blast_UTR3_${EXON}.txt)" == "$(cut -f6 best_blast_UTR3_${EXON}.txt)" )) ; then
				blast_utr="ok";
			else
				blast_utr="notok";
			fi ;
		else
			exon_seq_start=1
			exon_seq_end=$(cut -f10 blast_UTR3_${EXON}.txt)
			blast_length=$(cut -f5 blast_UTR3_${EXON}.txt)
			utr_length=$(cut -f7 blast_UTR3_${EXON}.txt)
			if (( "$(cut -f11 blast_UTR3_${EXON}.txt)" == "$(cut -f6 blast_UTR3_${EXON}.txt)" )) ; then
				blast_utr="ok";
			else
				blast_utr="notok";
			fi ;
		fi
		
		if [ $blast_utr == "ok"  ]; then
			grep -w "${EXON}" ${EXONS_SEQ} > ${EXON}_header.txt
			sed -i 's/>//g' ${EXON}_header.txt
			seqkit grep -n -f ${EXON}_header.txt ${EXONS_SEQ} -o ${EXON}_seq.fasta
			echo -e "${EXON}\t${exon_seq_start}\t${exon_seq_end}" >> start_end_exons.txt 
			seqkit subseq -r ${exon_seq_start}:${exon_seq_end} ${EXON}_seq.fasta > ${EXON}_coding_seq.fasta
			grep -v ">" ${EXON}_coding_seq.fasta > ${EXON}_coding_seq_seqonly.txt
			echo -e ">$(cat ${EXON}_header.txt)\n$(cat ${EXON}_coding_seq_seqonly.txt)"
			echo -e "${EXON}\t${utr_length}\t${blast_length}" >> utr_blast_lengths.csv ;
		fi
	fi	

# exon at both	
else
	echo -e "${EXON}\tBOTH" >> positions.txt
	# start
	grep -w "${EXON}" ${BLAST_UTR_5} |\
	awk -v exon=${EXON} '$1 ~ exon && $2 ~ exon {print $0}' > blast_UTR5_${EXON}.txt
	
	if [ $(wc -l < blast_UTR5_${EXON}.txt) -eq 0 ]; then
		echo -e "${EXON}" >> list_exons_start_sans_seq_UTR5.txt
		blast_utr_5="notok" ;
	elif [ $(wc -l < blast_UTR5_${EXON}.txt) -gt 1 ]; then
		echo -e "${EXON}" >> list_exons_start_plusieurs_seq_UTR5.txt
		min_evalue=$(sort -g -k3 blast_UTR5_${EXON}.txt | head -1 | cut -f3)
		max_long=$(LC_ALL=en_US awk -v min=${min_evalue} '{if ($3==min) {print $0}}' blast_UTR5_${EXON}.txt | sort -k5 -r | head -1 | cut -f5)
		LC_ALL=en_US awk -v min=${min_evalue} '{if ($3==min) {print $0}}' blast_UTR5_${EXON}.txt | \
		LC_ALL=en_US awk -v max=${max_long} '{if ($5==max) {print $0}}' | \
		sort -k4 -r | head -1 > best_blast_UTR5_${EXON}.txt
		exon_seq_start=$(cut -f11 best_blast_UTR5_${EXON}.txt)
		blast_length_start=$(cut -f5 best_blast_UTR5_${EXON}.txt)
		utr_length_start=$(cut -f7 best_blast_UTR5_${EXON}.txt)
		if [ $(cut -f10 best_blast_UTR5_${EXON}.txt) -eq 1 ]; then
			blast_utr_5="ok";
		else
			blast_utr_5="notok";
		fi ;
	else
		exon_seq_start=$(cut -f11 blast_UTR5_${EXON}.txt)
		blast_length_start=$(cut -f5 blast_UTR5_${EXON}.txt)
		utr_length_start=$(cut -f7 blast_UTR5_${EXON}.txt)
		if [ $(cut -f10 blast_UTR5_${EXON}.txt) -eq 1 ]; then
			blast_utr_5="ok";
		else
			blast_utr_5="notok";
		fi ;
	fi
	
	# end
	grep -w "${EXON}" ${BLAST_UTR_3} |\
	awk -v exon=${EXON} '$1 ~ exon && $2 ~ exon {print $0}' > blast_UTR3_${EXON}.txt

	if [ $(wc -l < blast_UTR3_${EXON}.txt) -eq 0 ]; then
		echo -e "${EXON}" >> list_exons_end_sans_seq_UTR3.txt
		blast_utr_3="notok" ;
	elif [ $(wc -l < blast_UTR3_${EXON}.txt) -gt 1 ]; then
		echo -e "${EXON}" >> list_exons_end_plusieurs_seq_UTR3.txt
		min_evalue=$(sort -g -k3 blast_UTR3_${EXON}.txt | head -1 | cut -f3)
		max_long=$(LC_ALL=en_US awk -v min=${min_evalue} '{if ($3==min) {print $0}}' blast_UTR3_${EXON}.txt | sort -k5 -r | head -1 | cut -f5)
		LC_ALL=en_US awk -v min=${min_evalue} '{if ($3==min) {print $0}}' blast_UTR3_${EXON}.txt | \
		LC_ALL=en_US awk -v max=${max_long} '{if ($5==max) {print $0}}' | \
		sort -k4 -r | head -1 > best_blast_UTR3_${EXON}.txt
		exon_seq_end=$(cut -f10 best_blast_UTR3_${EXON}.txt)
		blast_length_end=$(cut -f5 best_blast_UTR3_${EXON}.txt)
		utr_length_end=$(cut -f7 best_blast_UTR3_${EXON}.txt)
		if (( "$(cut -f11 best_blast_UTR3_${EXON}.txt)" == "$(cut -f6 best_blast_UTR3_${EXON}.txt)" )) ; then
			blast_utr_3="ok";
		else
			blast_utr_3="notok";
		fi ;
	else
		exon_seq_end=$(cut -f10 blast_UTR3_${EXON}.txt)
		blast_length_end=$(cut -f5 blast_UTR3_${EXON}.txt)
		utr_length_end=$(cut -f7 blast_UTR3_${EXON}.txt)
		if (( "$(cut -f11 blast_UTR3_${EXON}.txt)" == "$(cut -f6 blast_UTR3_${EXON}.txt)" )) ; then
			blast_utr_3="ok";
		else
			blast_utr_3="notok";
		fi ;
	fi
	
	if [ $blast_utr_5 == "ok" ] && [ $blast_utr_3 == "ok" ]; then
		grep -w "${EXON}" ${EXONS_SEQ} > ${EXON}_header.txt
		sed -i 's/>//g' ${EXON}_header.txt
		seqkit grep -n -f ${EXON}_header.txt ${EXONS_SEQ} -o ${EXON}_seq.fasta
		echo -e "${EXON}\t${exon_seq_start}\t${exon_seq_end}" >> start_end_exons.txt 
		seqkit subseq -r ${exon_seq_start}:${exon_seq_end} ${EXON}_seq.fasta > ${EXON}_coding_seq.fasta
		grep -v ">" ${EXON}_coding_seq.fasta > ${EXON}_coding_seq_seqonly.txt
		echo -e ">$(cat ${EXON}_header.txt)\n$(cat ${EXON}_coding_seq_seqonly.txt)"
		echo -e "${EXON}\t${utr_length_start}\t${blast_length_start}\n${EXON}\t${utr_length_end}\t${blast_length_end}" >> utr_blast_lengths.csv
	fi
fi


# delete intermediate files ## 

if [ ${suppr} == 1 ] ; then
	rm ${EXON}_coding_seq.fasta
	rm ${EXON}_coding_seq_seqonly.txt
	rm ${EXON}_header.txt
	rm ${EXON}_seq.fasta
	rm ${EXON}_seq.fasta.seqkit.fai
	rm *_UTR3_${EXON}.txt
	rm *_UTR5_${EXON}.txt
fi
