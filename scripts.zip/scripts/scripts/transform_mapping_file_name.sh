#! /bin/bash

EXON=$1

cp ''"${EXON}"'_counts_dN_X_S->S.count' correct_file_names/${EXON}_counts_dN_X_SS.csv
cp ''"${EXON}"'_counts_dN_X_S->W.count' correct_file_names/${EXON}_counts_dN_X_SW.csv
cp ''"${EXON}"'_counts_dN_X_W->W.count' correct_file_names/${EXON}_counts_dN_X_WW.csv
cp ''"${EXON}"'_counts_dN_X_W->S.count' correct_file_names/${EXON}_counts_dN_X_WS.csv
cp ''"${EXON}"'_counts_dS_X_S->S.count' correct_file_names/${EXON}_counts_dS_X_SS.csv
cp ''"${EXON}"'_counts_dS_X_S->W.count' correct_file_names/${EXON}_counts_dS_X_SW.csv
cp ''"${EXON}"'_counts_dS_X_W->W.count' correct_file_names/${EXON}_counts_dS_X_WW.csv
cp ''"${EXON}"'_counts_dS_X_W->S.count' correct_file_names/${EXON}_counts_dS_X_WS.csv

