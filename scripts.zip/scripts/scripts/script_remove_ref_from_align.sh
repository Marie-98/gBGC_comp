#! /bin/bash

# Arguments ###

EXON=$1
TRIBE=$2

# Script ###

# recuperer nom gene
GENE=$(grep -w ${EXON} ~/Murinae/Reference_exons/Gene_exons_ref_list.txt | cut -f1)
POS=$(grep -w ${EXON} ~/Murinae/Reference_exons/Gene_exons_ref_list.txt | cut -f3)

# remove ref
python3 ~/scripts/remove_ref_from_align.py ~/Murinae/${TRIBE}/Aligned_Sequences/alignments/${GENE}_${EXON}_${POS}_final_align_NT.aln ~/Murinae/Reference_exons/Complete_names_Mouse_exons_ref_coding_seq_lgmin100.txt ~/Murinae/${TRIBE}/Aligned_Sequences/alignments/alignments_wt_ref/${GENE}_${EXON}_${POS}_final_align_NT_wt_ref.fasta
