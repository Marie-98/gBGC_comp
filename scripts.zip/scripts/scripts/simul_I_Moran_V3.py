## install packages ###
import sys
import random
import pandas as pd
from statistics import mean
import numpy

## arguments ###

 # message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 5:
    sys.exit("ERROR : need 4 arguments : [1]csv file of stat nb subst [2]length of the sequence [3]name of out file [4]number of simulations")
    # recuperer les arguments
tab_subst = sys.argv[1]
seq_len = sys.argv[2]
out_file = sys.argv[3]
nb_simul = sys.argv[4]

## script ###

tab_nb_subst = pd.read_csv(tab_subst, sep="\t")
tab_nb_subst = tab_nb_subst[tab_nb_subst['nb_subst_WS'] >= 2.9]
branches = list(tab_nb_subst['branches'])
print(branches)

col_simul = list((range(1, int(nb_simul)+1)))
col_simul = ["branches"] + col_simul

if branches:
    for br in branches:
        nb_subst_br = float(tab_nb_subst[tab_nb_subst['branches'] == br]['nb_subst_WS'].iloc[0])
        nb_subst_br = int(round(nb_subst_br))
        I_list = []
        for simul in range(1, int(nb_simul) + 1):
            simul_subst_distrib = [0] * int(seq_len)
            ### Simul distribution of substitutions
            for subst in range(1,nb_subst_br+1):
                position = random.randint(0,int(seq_len)-1)
                simul_subst_distrib[position] = simul_subst_distrib[position] + 1
            ### I Moran
            simul_subst_distrib_array = numpy.array(simul_subst_distrib)
            Z = simul_subst_distrib_array - mean(simul_subst_distrib)
            num = 0
            denom = 0
            S = 0
            for i in range(1,int(seq_len)):
                Z_i = Z[i - 1]
                for j in range(i+1,int(seq_len)+1):
                    W_i_j = 1/(abs(i-j))
                    Z_j = Z[j-1]
                    num = num + (W_i_j * Z_i * Z_j)
                    S = S + W_i_j
                denom = denom + (Z_i * Z_i)
            denom = denom + Z[-1] * Z[-1]
            I = (int(seq_len)/S) * (num/denom)
            I_list.append(I)
        ligne_br = [br] + I_list
        if br == branches[0]:
            tab_simul_I = pd.DataFrame([ligne_br], columns=col_simul)
        else:
            tab = pd.DataFrame([ligne_br], columns=col_simul)
            tab_simul_I = pd.concat([tab_simul_I, tab], ignore_index=True)
    tab_simul_I.to_csv(out_file, index=False)

