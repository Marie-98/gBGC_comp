#! /bin/bash

# parametres ##

REF=$1 # list of exons seq ref
UTR_5=$2 # 5' UTR seq
UTR_3=$3 # 3' UTR seq
THREADS=$4 # number of threads to use

# créer une base de données des séquences de référence de la souris, si elle n'est pas déjà créée #
if [[ ! -e ${REF}.ndb && ! -e ${REF}.nhr && ! -e ${REF}.nin && ! -e ${REF}.not && ! -e ${REF}.nsq && ! -e ${REF}.ntf && ! -e ${REF}.nto ]] ; then
	makeblastdb -in ${REF} -dbtype nucl ;
fi

# blast 5'UTR vs exons
blastn  -query ${UTR_5} -db ${REF} -num_threads ${THREADS} -evalue 1e-10 -outfmt '6 sseqid qseqid evalue pident length slen qlen qstart qend sstart send mismatch' > blast_UTR_5_vs_exons.txt

# blast 3'UTR vs exons
blastn  -query ${UTR_3} -db ${REF} -num_threads ${THREADS} -evalue 1e-10 -outfmt '6 sseqid qseqid evalue pident length slen qlen qstart qend sstart send mismatch' > blast_UTR_3_vs_exons.txt
