## Install packages ###
import sys
from ete3 import Tree
import pandas as pd

## arguments ###

 # message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 4:
    sys.exit("ERROR : need 3 arguments : [1]path to the tree of the gene [2]path to the table of the branches name and number correspondence (first column name if it's a leaf or num if it's in internal branch, second column num ; sep=',') [3]name of the out csv file")
    # recuperer les arguments
tree_name = sys.argv[1]
tab_br_num = sys.argv[2]
out_file = sys.argv[3]

## script ###

# read the tree
t = Tree(tree_name, format=3)
leaves_list = t.get_leaf_names() # list of the tree leaves

# read the table of the branches name/num correspondence
tab_br_name_num = pd.read_csv(tab_br_num, sep=",")
#print(tab_br_name_num.head())
#name = 'Apomys_lubangensis'
#num = str(tab_br_name_num[tab_br_name_num['name'] == name]['num'].iloc[0])
#print(num)
# open csv file to write results
with open(out_file, 'w') as out:
  out.write(f'Br_num\tAsc_Br\tDesc_Br_1\tDesc_Br_2\n')
  # for each node of the tree :
  for node in t.iter_descendants("postorder"):
    node_name = node.name # get the node name
    if node_name in leaves_list:
      node_name = str(tab_br_name_num[tab_br_name_num['name'] == node_name]['num'].iloc[0])
    nodeup = node.up # get the ascendant node
    nodeup_name = nodeup.name # get the ascendant node name
    if not nodeup_name:
      nodeup_name = 'NA'  
    nodechild = node.children # get the descendants nodes
    if (nodechild): # if there are descendants nodes (the node is an internal node)
      nodechild1 = nodechild[0] # get the first descendant node
      nodechild1_name = nodechild1.name # get the first descendant node name
      if nodechild1_name in leaves_list:
        nodechild1_name = str(tab_br_name_num[tab_br_name_num['name'] == nodechild1_name]['num'].iloc[0])
      nodechild2 = nodechild[1] # get the second descendant node
      nodechild2_name = nodechild2.name # get the second descendant node name
      if nodechild2_name in leaves_list:
        nodechild2_name = str(tab_br_name_num[tab_br_name_num['name'] == nodechild2_name]['num'].iloc[0])
    else: # if there are not descendants nodes (the node is a leaf)
      nodechild1_name = 'NA'
      nodechild2_name = 'NA'
    out.write(f'{node_name}\t{nodeup_name}\t{nodechild1_name}\t{nodechild2_name}\n')
