## Install packages ###
import sys
from Bio import SeqIO
import pandas as pd

## Arguments ###
    # error message if the number of arguments is wrong
if len(sys.argv) != 8:
    sys.exit("ERROR : need 7 arguments : [1] list of species [2] list of exons [3] path to the directory where are the seq alignments [4] path to the directory where are the tables of exons infos [5] het filter parameter (number of sd : 4 for exemple) [6] seuil min cov depth (ex:5) [7] max cov depth filter parameter (number of sd : 3 for exemple)")
    # get the arguments
species = sys.argv[1]
exons = sys.argv[2]
path_to_seq = sys.argv[3]
path_to_tab = sys.argv[4]
het_filter_param = sys.argv[5]
seuil_min_cov_depth_filter = sys.argv[6]
param_seuil_max_cov_depth_filter = sys.argv[7]

## Build species list ###
with open(species, "r") as file_sp:
    sp_read = file_sp.read().strip()
    sp_list = sp_read.split()
    #print(sp_list)

## Build exons list ###
with open(exons, "r") as file_exons:
    exons_read = file_exons.read().strip()
    exons_list = exons_read.split()
    #print(exons_list)

## Build dico of exon : species ###
dico_exon_sp = {} # create an empty dico
for exon in exons_list:
    dico_exon_sp[exon] = []
print(dico_exon_sp)

## 1 ### Get list of exons which pass the heterozygotie et mean cov depth filters #########################################################

for sp in sp_list: # for each specie
    tab_name = f'{path_to_tab}{sp}_Exons_tab_infos_final.csv' # path et name of csv table to open
    tab_info_exons = pd.read_csv(tab_name, sep="\t", header=None) # open the csv table
    tab_info_exons.columns = ['Gene', 'Exon', 'mean_cov_depth', 'het'] # rename columns
    #print(tab_info_exons.head())
    #print(tab_info_exons.shape)
    het_mean = tab_info_exons["het"].mean() # calculate mean heterozygosity
    het_sd = tab_info_exons["het"].std() # calculate standard deviation of heterozygosity
    cov_depth_mean = tab_info_exons["mean_cov_depth"].mean() # calculate mean of mean coverage depth
    cov_depth_sd = tab_info_exons["mean_cov_depth"].std() # calculate standard deviation of mean coverage depth
    #print(het_mean)
    #print(het_sd)
    seuil_het = het_mean + float(het_filter_param) * het_sd # calculate max threshold of heterozygosity
    #print(seuil_het)
    seuil_min_cov_depth = float(seuil_min_cov_depth_filter) # min threshold of mean coverage depth
    #print(seuil_min_cov_depth)
    seuil_max_cov_depth = cov_depth_mean + float(param_seuil_max_cov_depth_filter) * cov_depth_sd # max threshold of mean coverage depth
    #print(seuil_max_cov_depth)
    for row in tab_info_exons.itertuples(): # for each row of the csv table
        het = row[4] # get heterozygosity
        mean_cov_depth = row[3] # get mean cov depth
        exon_name = row[2] # get exon name
        if het < seuil_het and seuil_min_cov_depth < mean_cov_depth < seuil_max_cov_depth: # if het and mean cov depth are in the thresholds
            if exon_name not in dico_exon_sp: # if the exon is not in the dico
                dico_exon_sp[exon_name] = [sp] # create exon and add specie in a list
            else: # if exon is already in the dico
                dico_exon_sp[exon_name].append(sp) # add specie in the list of the exon
print(dico_exon_sp)


### 2 ### Create new alignment fasta file (one per exon) which contains only seq which pass the conditions (which are in the dico) ########

gene_exon_position_tab = pd.read_csv("~/Murinae/Reference_exons/Gene_exons_ref_list.txt", sep="\t", header=None) # open the csv table which contains infos on gene and position of the exons
for exon in exons_list: # for each exon
    gene_exon_position_tab.columns = ['Gene', 'Exon', 'Position'] # rename columns
    tab_exon = gene_exon_position_tab[gene_exon_position_tab['Exon'] == exon] # get the line of te exon in the tab
    #print(tab_exon)
    gene = tab_exon.iloc[0,0] # get the gene of the exon
    #print(gene)
    position = tab_exon.iloc[0,2] # get the exon position
    #print(position)
    seq_file_name = f'{path_to_seq}{gene}_{exon}_{position}_final_align_NT_wt_ref.fasta' # name of the alignement file for the exon
    #print(seq_file_name)
    out_seq_file_name = f'{path_to_seq}{gene}_{exon}_{position}_final_align_NT_wt_ref_filtered.fasta' # name of the out alignment file for the exon which will contain only sequences which passed the filter
    with open(out_seq_file_name, 'w') as out: # open fasta file
        for seq_read in SeqIO.parse(seq_file_name, 'fasta'): # for each seq read seq
            seq_id = seq_read.id #get seq id
            if seq_id in dico_exon_sp[exon]: # if seq id is in the list of species for this exon (i.e. if seq has passed the filter)
                out.write(f'>{seq_id}\n') # write the id name in the out alignment file
                seq_seq = seq_read.seq # get the sequence
                out.write(f'{seq_seq}\n') # write the sequence in the out alignment file
