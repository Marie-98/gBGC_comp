## install packages ###
import sys
import pandas as pd
import numpy as np

# message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 4:
    sys.exit("ERROR : need 3 arguments : [1]gene name [2]directory of the tab recap [3]list of paralogs exons")
# recuperer les arguments
gene_name = sys.argv[1]
tab_recap_dir = sys.argv[2]
paralogs_list_file = sys.argv[3]

## script ###

# get the paralogs list
with open(paralogs_list_file, "r") as file_paralogs_list:
    file_paralogs_list_read = file_paralogs_list.read().strip()
    paralogs_list = file_paralogs_list_read.split()

gene = gene_name
print(gene)
# read the table
tab_recap_name = tab_recap_dir + gene + "_tab_recap.csv"
tab_recap_with_paralogs = pd.read_csv(tab_recap_name, sep='\t')
    
# remove paralogs exons
tab_recap = tab_recap_with_paralogs[~tab_recap_with_paralogs.Exon.isin(paralogs_list)]

# list exons
exons_list = list(tab_recap['Exon'])
exons_list = set(exons_list) # equivalent of uniq
exons_list = list(exons_list) # equivalent of uniq
print(exons_list)

# 
gene_list = []
exon_list = []
GC3_list = []
lg_seq_list = []
br_ep_list = []
ep_list = []
nb_WS_ep_list = []
nb_SW_ep_list = []
nb_WS_postep_list = []
nb_SW_postep_list = []

# list branches episodes
tab_recap_ep = tab_recap[(tab_recap['Episode'] == 'YES') & (pd.notna(tab_recap['Br_Asc'])) & (pd.notna(tab_recap['Br_Desc1']))]
br_ep = list(tab_recap_ep['Br'])
br_ep = set(br_ep)
br_ep = list(br_ep)
print(br_ep)


###
for exon in exons_list:
# tab exon
    tab_exon = tab_recap[tab_recap['Exon'] == exon]
# for each br ep get br post ep and infos
    for br in br_ep:
    # get br post
        br_post1 = tab_exon[tab_exon['Br'] == br]['Br_Desc1'].iloc[0]
        br_post2 = tab_exon[tab_exon['Br'] == br]['Br_Desc2'].iloc[0]
    # get infos
        GC3 = tab_exon[tab_exon['Br'] == br]['GC3'].iloc[0]
        lg_seq = tab_exon[tab_exon['Br'] == br]['Lg_seq'].iloc[0]
        ep = tab_exon[tab_exon['Br'] == br]['Episode'].iloc[0]
        nb_WS_ep = tab_exon[tab_exon['Br'] == br]['Nb_subst_S_WS'].iloc[0]
        nb_SW_ep = tab_exon[tab_exon['Br'] == br]['Nb_subst_S_SW'].iloc[0]
        nb_WS_postep1 = tab_exon[tab_exon['Br'] == br_post1]['Nb_subst_S_WS'].iloc[0]
        nb_WS_postep2 = tab_exon[tab_exon['Br'] == br_post2]['Nb_subst_S_WS'].iloc[0]
        nb_WS_postep = nb_WS_postep1 + nb_WS_postep2
        nb_SW_postep1 = tab_exon[tab_exon['Br'] == br_post1]['Nb_subst_S_SW'].iloc[0]
        nb_SW_postep2 = tab_exon[tab_exon['Br'] == br_post2]['Nb_subst_S_SW'].iloc[0]
        nb_SW_postep = nb_SW_postep1 + nb_SW_postep2
    # fill the lists
        gene_list.append(gene)
        exon_list.append(exon)
        GC3_list.append(GC3)
        lg_seq_list.append(lg_seq)
        br_ep_list.append(br)
        ep_list.append(ep)
        nb_WS_ep_list.append(nb_WS_ep)
        nb_SW_ep_list.append(nb_SW_ep)
        nb_WS_postep_list.append(nb_WS_postep)
        nb_SW_postep_list.append(nb_SW_postep)
        
# make the table
tab = pd.DataFrame({'Gene' : gene_list,
		     'Exon' : exon_list,
		     'GC3' : GC3_list,
		     'Lg_seq' : lg_seq_list,
		     'Br_ep' : br_ep_list,
		     'Episode' : ep_list,
		     'Nb_S_WS_ep' : nb_WS_ep_list,
		     'Nb_S_SW_ep' : nb_SW_ep_list,
		     'Nb_S_WS_postep' : nb_WS_postep_list,
		     'Nb_S_SW_postep' : nb_SW_postep_list})


# save the table
tab.to_csv(gene + '_tab_for_sort_ep.csv', index=False)














    

