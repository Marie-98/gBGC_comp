#! /bin/bash

# parametres ## 

SPECIE=$1
TRIBE=$2

# script ##

for EXON in $(cat ~/Murinae/${TRIBE}/Sequences/Exons_list.txt); do

	# informations

	GENE=$(grep -w ${EXON} ~/Murinae/Reference_exons/Gene_exons_ref_list.txt | cut -f1)

	EXON_POSITION=$(grep -w ${EXON} ~/Murinae/Reference_exons/Gene_exons_ref_list.txt | cut -f3)

	CONTIG=$(LC_ALL=en_US awk '{if ($12=="yes") {print $0}}' ~/Murinae/${TRIBE}/Blast/reciprocal_blast/${SPECIE}/sortie_blast_reciproque_${SPECIE}.csv |\
	grep "${EXON}" |\
	cut -f6)

	DEBUT=$(LC_ALL=en_US awk '{if ($12=="yes") {print $0}}' ~/Murinae/${TRIBE}/Blast/reciprocal_blast/${SPECIE}/sortie_blast_reciproque_${SPECIE}.csv |\
	grep "${EXON}" |\
	cut -f7)

	FIN=$(LC_ALL=en_US awk '{if ($12=="yes") {print $0}}' ~/Murinae/${TRIBE}/Blast/reciprocal_blast/${SPECIE}/sortie_blast_reciproque_${SPECIE}.csv |\
	grep "${EXON}" |\
	cut -f8)

	for INDIV in $(grep ${SPECIE} ~/Murinae/${TRIBE}/Data/recap_sequencing_${TRIBE}.csv | cut -f2 -d',') ; do
		
		# nombre de reads :
		#NB_READS=$(samtools coverage -H -r ${CONTIG}:${DEBUT}-${FIN} ~/Murinae/Mapping/${TRIBE}/${SPECIE}/${INDIV}_bwa_sorted_bam.bam | cut -f4)

		# % de bases couvertes :
		#COVERAGE=$(samtools coverage -H -r ${CONTIG}:${DEBUT}-${FIN} ~/Murinae/Mapping/${TRIBE}/${SPECIE}/${INDIV}_bwa_sorted_bam.bam | cut -f6)

		# profondeur moyenne de couverture :
		MEAN_DEPTH=$(samtools coverage -H -r ${CONTIG}:${DEBUT}-${FIN} ~/Murinae/${TRIBE}/Mapping/${INDIV}_bwa_sorted_bam.bam | cut -f7)

		# % de GC :
		#GC=$(seqkit fx2tab ~/Murinae/Blast/blast_reciproque/${TRIBE}/${SPECIE}/${GENE}_${EXON}_${EXON_POSITION}_seq.fasta -g -n | cut -f2)
		
		echo -e "${GENE}\t${EXON}\t${INDIV}\t${MEAN_DEPTH}"
	done >> ${SPECIE}_${EXON}_tab_infos.csv
	
	#NB_READS_MOY=$(awk '{ sum += $4 } END { print (sum / NR)}' ${SPECIE}_${EXON}_tab_infos.csv)

	#COVERAGE_MOY=$(awk '{ sum += $5 } END { print (sum / NR)}' ${SPECIE}_${EXON}_tab_infos.csv)

	MEAN_DEPTH_MOY=$(awk '{ sum += $4 } END { print (sum / NR)}' ${SPECIE}_${EXON}_tab_infos.csv)

	#GC_MOY=$(awk '{ sum += $7 } END { print (sum / NR)}' ${SPECIE}_${EXON}_tab_infos.csv)
	
	HET_MOY=$(grep "${EXON}" ~/Murinae/${TRIBE}/Heterozygosity/${SPECIE}/tab_heterozygotie_${SPECIE}.csv | cut -f3)
		
	echo -e "${GENE}\t${EXON}\t${MEAN_DEPTH_MOY}\t${HET_MOY}"
		
	rm ${SPECIE}_${EXON}_tab_infos.csv
	
done >> ${SPECIE}_Exons_tab_infos.csv
