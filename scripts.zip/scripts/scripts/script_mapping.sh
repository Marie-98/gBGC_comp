#! /bin/bash

# paramètres ####

THREADS=$1
INDIV=$2
TRIBE=$3

# script ########

# génome de référence
SPECIE=$(grep ${INDIV} ~/Murinae/${TRIBE}/Data/recap_sequencing_${TRIBE}.csv | cut -f1 -d',')
REF=~/Murinae/${TRIBE}/Assembly/trinity_OUT_${SPECIE}.Trinity.fasta

# entrer dans dossier de l'espèce
cd ${SPECIE}

# créer l'index du génome de référence (s'il n'existe pas déjà)
if [[ ! -e ${REF}.amb && ! -e ${REF}.ann && ! -e ${REF}.bwt && ! -e ${REF}.pac && ! -e ${REF}.sa ]] ; then
	bwa index ${REF}
fi

# reads à mapper
nb_indiv=$(grep -c ${SPECIE} ~/Murinae/${TRIBE}/Data/recap_sequencing_${TRIBE}.csv)
if [ ${nb_indiv} == 1 ] ; then
	READS_F=~/Murinae/${TRIBE}/Data/cleaned_pooled_reads/${SPECIE}_all_R1.clean.fastq.gz
	READS_R=~/Murinae/${TRIBE}/Data/cleaned_pooled_reads/${SPECIE}_all_R2.clean.fastq.gz ;
	else
	READS_F=~/Murinae/${TRIBE}/Data/cleaned_pooled_reads/${INDIV}_all_R1.clean.fastq.gz
	READS_R=~/Murinae/${TRIBE}/Data/cleaned_pooled_reads/${INDIV}_all_R2.clean.fastq.gz ;
fi

# mapping
bwa mem -t ${THREADS} ${REF} ${READS_F} ${READS_R} > ${INDIV}_bwa.sam

# indexation du génome de référence
if [[ ! -e ${REF}.fai ]] ; then
	samtools faidx ${REF}
fi

# compression des mappings
samtools view -bt ${REF} ${INDIV}_bwa.sam > ${INDIV}_bwa.bam

# tri des fichiers bam
samtools sort ${INDIV}_bwa.bam -o ${INDIV}_bwa_sorted_bam.bam

# indexation des fichiers bam
samtools index ${INDIV}_bwa_sorted_bam.bam

# sortir du dossier de l'espèce
cd ..
