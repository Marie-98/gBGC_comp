#! /bin/bash

# paramètres #
QUERY=$1
TRIBE=$2
SPECIE=$3
LONGMIN=$4
PIDENTMIN=$5
PERCENTMIN=$6
THREADS=$7

# reference
REF=~/Murinae/${TRIBE}/Assembly/trinity_OUT_${SPECIE}.Trinity.fasta

# créer une base de données des séquences de référence de la souris, si elle n'est pas déjà créée #
if [[ ! -e ${REF}.ndb && ! -e ${REF}.nhr && ! -e ${REF}.nin && ! -e ${REF}.not && ! -e ${REF}.nsq && ! -e ${REF}.ntf && ! -e ${REF}.nto ]] ; then
	makeblastdb -in ${REF} -dbtype nucl ;
fi

# creer repertoire pour l'espece
mkdir ${SPECIE}

# y entrer
cd ${SPECIE}

# faire le blast #
blastn -query ${QUERY} -db ${REF} -num_threads $THREADS -evalue 1e-10 -outfmt '6 sseqid qseqid evalue pident length slen qlen qstart qend sstart send mismatch' > blast_exons_vs_contigs_${SPECIE}.txt

# donner indications sur le blast #
nb_blast=$(wc -l blast_exons_vs_contigs_${SPECIE}.txt)
nb_exons=$(cut -f2 blast_exons_vs_contigs_${SPECIE}.txt | sort -u | wc -l)
nb_contigs=$(cut -f1 blast_exons_vs_contigs_${SPECIE}.txt | sort -u | wc -l)

echo "espèce : ${SPECIE}"
echo "nombre de blast : $nb_blast"
echo "nombre d'exons ayant blasté : $nb_exons"
echo "nombre de contigs trouvés : $nb_contigs"

# filtrer le blast #
LC_ALL=en_US awk -v longmin=${LONGMIN} '{if ($5>longmin) {print $0}}' blast_exons_vs_contigs_${SPECIE}.txt |\
LC_ALL=en_US awk -v seuilpident=${PIDENTMIN} '{if ($4>seuilpident) {print $0}}' |\
LC_ALL=en_US awk -v seuilpercent=${PERCENTMIN} '{if (($5/$7)>=seuilpercent) {print $0}}' > blast_exons_vs_contigs_filtre_${SPECIE}.txt

# donner indications sur le blast filtré #
nb_blast_filtre=$(wc -l blast_exons_vs_contigs_filtre_${SPECIE}.txt)
nb_exons_filtre=$(cut -f2 blast_exons_vs_contigs_filtre_${SPECIE}.txt | sort -u | wc -l)
nb_contigs_filtre=$(cut -f1 blast_exons_vs_contigs_filtre_${SPECIE}.txt | sort -u | wc -l)

echo "nombre de blast filtre : $nb_blast_filtre"
echo "nombre d'exons ayant blasté filtre : $nb_exons_filtre"
echo "nombre de contigs trouvés filtre : $nb_contigs_filtre"

# créer fichier des noms des exons qui ont blasté
cut -f2 blast_exons_vs_contigs_filtre_${SPECIE}.txt | cut -f2 -d"|" | sort -u > exons_list_blast_${SPECIE}.txt

# sortir du repertoire de l'espèce
cd ../
