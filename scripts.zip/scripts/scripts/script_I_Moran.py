## install packages ###
import sys
import pandas as pd
import numpy as np

# message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 4:
    sys.exit("ERROR : need 3 arguments : [1]exon name [2]path to the directory of the mapping substitution tables [3]csv out name")
    # recuperer les arguments
exon_name = sys.argv[1]
subst_tab_dir = sys.argv[2]
out_file_name = sys.argv[3]

## script ###

## subst WS
tab_WS_name = subst_tab_dir + exon_name + "_counts_dS_X_WS.csv"
tab_WS = pd.read_csv(tab_WS_name, sep='\t')
tab_WS[tab_WS < 0.9] = 0

I_list_WS = []
branch_number = []

for br in range(0,len(tab_WS.columns)-1):
    br = str(br)
    branch_number.append(br)
    subst_list = list(tab_WS[br])
    if np.sum(subst_list) > 2.9:
        Z = subst_list - np.mean(subst_list)
        n = int(len(subst_list))
        num = 0
        denom = 0
        S = 0
        for i in range(1,n):
            Z_i = Z[i-1]
            for j in range(i+1,n+1):
                W_i_j = 1/(abs(i-j))
                Z_j = Z[j-1]
                num = num + (W_i_j * Z_i * Z_j)
                S = S + W_i_j
            denom = denom + (Z_i * Z_i)
        denom = denom + Z[-1] * Z[-1]
        I = (n/S) * (num/denom)
    else:
        I = 'NA'
    I_list_WS.append(I)

## subst SW
tab_SW_name = subst_tab_dir + exon_name + "_counts_dS_X_SW.csv"
tab_SW = pd.read_csv(tab_SW_name, sep='\t')
tab_SW[tab_SW < 0.9] = 0

I_list_SW = []

for br in range(0,len(tab_SW.columns)-1):
    br = str(br)
    subst_list = list(tab_SW[br])
    if np.sum(subst_list) > 2.9:
        Z = subst_list - np.mean(subst_list)
        n = int(len(subst_list))
        num = 0
        denom = 0
        S = 0
        for i in range(1,n):
            Z_i = Z[i-1]
            for j in range(i+1,n+1):
                W_i_j = 1/(abs(i-j))
                Z_j = Z[j-1]
                num = num + (W_i_j * Z_i * Z_j)
                S = S + W_i_j
            denom = denom + (Z_i * Z_i)
        denom = denom + Z[-1] * Z[-1]
        I = (n/S) * (num/denom)
    else:
        I = 'NA'
    I_list_SW.append(I)

## make the table
I_table = pd.DataFrame({'branch_number': branch_number,
                        'WS': I_list_WS,
                        'SW': I_list_SW})

## save the table
I_table.to_csv(out_file_name, index=False)
