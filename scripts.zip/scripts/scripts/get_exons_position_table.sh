#! /bin/bash
exon=$1

gene=$(grep $exon Mouse_Exons_ref_geneID_exonID_transcriptID_CDSlength_exonrank.txt | cut -f2 -d">" | cut -f1 -d"|")
position=$(grep $exon Mouse_Exons_ref_geneID_exonID_transcriptID_CDSlength_exonrank.txt | cut -f2 -d">" | cut -f5 -d"|")
echo -e "${gene}\t${exon}\t${position}" >> gene_exon_position_ref_all.txt
