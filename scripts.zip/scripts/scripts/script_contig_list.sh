#! /bin/bash

# donne la correspondance entre exon ref et contig meilleur blast pour une espece donnee

# parametres ##

SPECIE=$1
TRIBE=$2

# script ##

for exon in $(cat ~/Murinae/${TRIBE}/Sequences/Exons_list.txt) ; do
	contig=$(LC_ALL=en_US awk '{if ($12=="yes") {print $0}}' ~/Murinae/${TRIBE}/Blast/reciprocal_blast/${SPECIE}/sortie_blast_reciproque_${SPECIE}.csv |\
	grep "${exon}"  | cut -f6)
	echo -e "${exon}\t${contig}"
done >> contigs_list_${SPECIE}.txt
