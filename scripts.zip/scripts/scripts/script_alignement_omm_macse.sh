#! /bin/bash

# parametres ##

EXON=$1
TRIBE=$2

# script ##

gene=$(grep -w ${EXON} ~/Murinae/Reference_exons/Gene_exons_ref_list.txt | cut -f1)
exon_position=$(grep -w ${EXON} ~/Murinae/Reference_exons/Gene_exons_ref_list.txt | cut -f3)

~/bin/vranwez_default_omm_macse.sif --no_prefiltering --in_seq_file ~/Murinae/Reference_exons/seq_ref_for_aln/${EXON}_seq_ref.fasta --in_seq_lr_file ~/Murinae/${TRIBE}/Sequences/${gene}_${EXON}_${exon_position}_all_sp_seq.fasta --out_dir ${gene}_${EXON}_${exon_position}_all_sp_seq_align --out_file_prefix ${gene}_${EXON}_${exon_position} --min_percent_NT_at_ends 0.1
