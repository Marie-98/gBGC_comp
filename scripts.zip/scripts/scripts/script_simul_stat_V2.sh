#! /bin/bash

# Arguments ###

EXON=$1
TRIBE=$2
NB_SIMUL=$3

# Script ###

GENE=$(grep -w ${EXON} ~/Murinae/Reference_exons/gene_exon_position_ref_all.txt | cut -f1)

cd Br_lg_tables
#if [[ ! -e ${GENE}_br_len.csv ]] ;then
~/bin/num_br_lg/tpn ~/Murinae/${TRIBE}/Phylogeny/gene_tree/${GENE}_tree.treefile ${GENE}_br_len.csv ;
#fi
cd ..

echo -e "exon : $EXON"

lg_seq=$(grep $EXON ~/Murinae/${TRIBE}/Aligned_Sequences/FINAL/exons_len.csv | cut -f2)
echo -e "lg seq = $lg_seq"

if [ ${lg_seq} -gt 999 ] ; then
cd I_Moran
python3 ~/scripts/simul_I_Moran_V3.py ~/Murinae/${TRIBE}/Detecting_gBGC/Distrib_subst_S/${EXON}_stat_nb_subst.csv ${lg_seq} ${EXON}_I_simul.csv $NB_SIMUL
cd ..
fi

cd Distrib_subst
python3 ~/scripts/simulation_distrib_subst_V2.py ~/Murinae/${TRIBE}/Detecting_gBGC/Distrib_subst_S/${EXON}_stat_nb_subst.csv ~/Murinae/${TRIBE}/Randomisations/Br_lg_tables/${GENE}_br_len.csv ${EXON}_distrib_subst_simul.csv $NB_SIMUL
cd ..
