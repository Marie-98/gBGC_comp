## install packages ###
from Bio import SeqIO
import sys
import pandas as pd

## arguments ###

    # message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 4:
    sys.exit("ERROR : need 3 arguments : [1]gene name [2]tab of genes, exons, position [3]directory of the sequences")
    # recuperer les arguments
gene_name = sys.argv[1]
genes_exons_pos_tab_name = sys.argv[2]
seq_dir = sys.argv[3]

# read tab of gene and exons
tab_genes_exons_pos = pd.read_csv(genes_exons_pos_tab_name, sep="\t", header=None)
tab_genes_exons_pos.columns = ['Gene', 'Exon', 'Position']

# list of exons for the gene
exons_list = list(tab_genes_exons_pos[tab_genes_exons_pos['Gene'] == gene_name]['Exon'])

# list of species for each exon
dico_exon_sp = {}
for exon in exons_list:
    dico_exon_sp[exon] = []
    pos = tab_genes_exons_pos[tab_genes_exons_pos['Exon'] == exon]['Position'].iloc[0]
    exon_align_name = f'{seq_dir}{gene_name}_{exon}_{pos}_final_align_NT_wt_ref_filtered_wt_stop.fasta'
    for seq_read in SeqIO.parse(exon_align_name, 'fasta'):
        sp = seq_read.id
        dico_exon_sp[exon].append(sp)

# find the common species between the exons
for i in range(1, len(exons_list)+1):
    exon = exons_list[i-1]
    if i == 1:
        sp_list = dico_exon_sp[exon]
    else:
        sp_list_exon = dico_exon_sp[exon]
        sp_list = list(set(sp_list) & set(sp_list_exon))

# get the sequences with these common species
for exon in exons_list:
    pos = tab_genes_exons_pos[tab_genes_exons_pos['Exon'] == exon]['Position'].iloc[0]
    seq_out_name = f'{gene_name}_{exon}_{pos}_FINAL_align_NT.fasta'
    exon_align_name = f'{seq_dir}{gene_name}_{exon}_{pos}_final_align_NT_wt_ref_filtered_wt_stop.fasta'
    with open(seq_out_name, 'w') as out:
        for seq_read in SeqIO.parse(exon_align_name, 'fasta'):
            seq_id = seq_read.id
            if seq_id in sp_list:
                out.write(f'>{seq_id}\n')
                seq_seq = seq_read.seq
                out.write(f'{seq_seq}\n')
