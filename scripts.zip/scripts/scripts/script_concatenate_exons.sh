#! /bin/bash

# parametres ##

SPECIE=$1
TRIBE=$2

# script ##

for EXON in $(cat ~/Murinae/${TRIBE}/Aligned_Sequences/alignments/alignments_wt_ref/alignments_wt_ref_filtered/alignments_wt_ref_filtered_wt_stop/Exons_filtered_final_list.txt); do

	gene=$(grep -w ${EXON} ~/Murinae/Reference_exons/Gene_exons_ref_list.txt | cut -f1)
	exon_position=$(grep -w ${EXON} ~/Murinae/Reference_exons/Gene_exons_ref_list.txt | cut -f3)
	sp_present=$(grep -c "${SPECIE}" ~/Murinae/${TRIBE}/Aligned_Sequences/alignments/alignments_wt_ref/alignments_wt_ref_filtered/alignments_wt_ref_filtered_wt_stop/${gene}_${EXON}_${exon_position}_final_align_NT_wt_ref_filtered_wt_stop.fasta)

	echo ">${EXON}"	
	
	if [ ${sp_present} == 0 ] ; then
		length=$(seqkit fx2tab ~/Murinae/${TRIBE}/Aligned_Sequences/alignments/alignments_wt_ref/alignments_wt_ref_filtered/alignments_wt_ref_filtered_wt_stop/${gene}_${EXON}_${exon_position}_final_align_NT_wt_ref_filtered_wt_stop.fasta -l -n | head -1 | cut -f2)
		printf 'N%.0s' $(seq 1 $length) 
		echo "" ;
		else
		echo "${SPECIE}" > ${SPECIE}_name.txt
		seqkit grep  -n -f ${SPECIE}_name.txt ~/Murinae/${TRIBE}/Aligned_Sequences/alignments/alignments_wt_ref/alignments_wt_ref_filtered/alignments_wt_ref_filtered_wt_stop/${gene}_${EXON}_${exon_position}_final_align_NT_wt_ref_filtered_wt_stop.fasta -o ${SPECIE}_${gene}_${EXON}_${exon_position}_seq_NT_aligned_final.fasta
		grep -v ">" ${SPECIE}_${gene}_${EXON}_${exon_position}_seq_NT_aligned_final.fasta
		rm ${SPECIE}_${gene}_${EXON}_${exon_position}_seq_NT_aligned_final.fasta
		rm ${SPECIE}_name.txt
	fi
done >> ${SPECIE}_all_seq_NT_aligned_final.fasta
