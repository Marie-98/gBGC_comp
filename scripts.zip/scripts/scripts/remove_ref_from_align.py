## Install packages ###
import sys
from Bio import SeqIO

## Arguments ###
    # error message if the number of arguments is wrong
if len(sys.argv) != 4:
    sys.exit("ERROR : need 3 arguments : [1]alignment file [2]list of exons ref names [3]out fasta file name")
    # get the arguments
align_name = sys.argv[1]
list_exons_ref_name = sys.argv[2]
out_file_name = sys.argv[3]

## Script ###

with open(list_exons_ref_name, "r") as file_ex_name:
    file_ex_name_read = file_ex_name.read().strip()
    ex_name_list = file_ex_name_read.split()

with open(out_file_name, "w") as out:
    for seq_read in SeqIO.parse(align_name, 'fasta'):
        seq_id = seq_read.id
        if seq_id not in ex_name_list:
            out.write(f'>{seq_id}\n')
            seq_seq = seq_read.seq
            out.write(f'{seq_seq}\n')
